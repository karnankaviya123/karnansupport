function New-AzureDevOpsPool {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $PoolName,

        [Parameter(Mandatory = $true)]
        [string] $ServiceConnectionName,

        [Parameter(Mandatory = $true)]
        [string] $SubscriptionId,

        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,

        [Parameter(Mandatory = $true)]
        [string] $ScaleSetName,

        [Parameter(Mandatory = $false)]
        [string] $MinCapacity = 0,

        [Parameter(Mandatory = $false)]
        [string] $MaxCapacity = 8,

        [Parameter(Mandatory = $false)]
        [string] $IdleTimeMinutes = 15
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'project' 'Get-AzureDevOpsProject.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'serviceEndpoint' 'Get-AzureDevOpsServiceEndpoint.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pool' 'Get-AzureDevOpsPools.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pool' 'Remove-AzureDevOpsPool.ps1')
    }

    process {
        Write-Verbose ("Check if Pool [{0}] exists in project {1}" -f $PoolName, $ProjectName) 
        $existing = (Get-AzureDevOpsPools -Organization $Organization -Project $ProjectName) | ?{ $_.Name.ToLowerInvariant() -Eq $PoolName.ToLowerInvariant() }
        
        ## DEBUG ONLY: delete pool if already exists
        # if($existing) {
        #     Write-Verbose ("Pool {0} already exists in project {1}, removing first" -f $PoolName, $ProjectName)
        #     Remove-AzureDevOpsPool -Organization $Organization -Project $ProjectName -PoolName $PoolName
        #     $existing = $NULL
        # }
        
        if($existing) {
            Write-Warning ("Pool {0} already exists in project {1}, exiting" -f $RepoName, $ProjectName)
            return ;
        }

        Write-Verbose ("Check if destination project [{0}] exists in organisation {1}" -f $ProjectName, $Organization) 
        $Project = Get-AzureDevOpsProject -Organization $Organization -Project $ProjectName
        if (-Not $Project) {
            Write-Error ("Project {0} not found in organisation {1}" -f $Organization, $ProjectName)
            return ;
        }

        Write-Verbose ("Check if service connection [{0}] exists in organisation {1}" -f $ServiceConnectionName, $Organization) 
        $ServiceEndpoint = Get-AzureDevOpsServiceEndpoint -Organization $Organization -Project $ProjectName | ?{ $_.Name.ToLowerInvariant() -Eq $ServiceConnectionName.ToLowerInvariant() }
        if (-Not $ServiceEndpoint) {
            Write-Error ("Service Endpoint {0} not found in organisation {1}" -f $ServiceEndpoint, $Organization)
            return ;
        }

        # Build command
        $body = @{
            "agentInteractiveUI" = $false
            "azureId" = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Compute/virtualMachineScaleSets/$ScaleSetName"
            "desiredIdle" = $MinCapacity
            "maxCapacity" = $MaxCapacity
            "osType" = 1
            "maxSavedNodeCount" = $MaxCapacity
            "recycleAfterEachUse" = $false
            "serviceEndpointId" = $ServiceEndpoint.id
            "serviceEndpointScope" = $Project.id
            "timeToLiveMinutes" = $IdleTimeMinutes
        }

        $restInfo = Get-RelativeConfigData -configToken 'RESTPoolCreate'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($PoolName), $Project.Id)
            body   = ConvertTo-Json $body -Depth 10 -Compress
        }
        
        # Execute command
        if ($PSCmdlet.ShouldProcess(('REST command to create Pool [{1}] in Project [{0}]' -f $Project, $PoolName), "Invoke")) {
            $createCommandResponse = Invoke-RESTCommand @restInputObject
            
            if (-not [String]::IsNullOrEmpty($createCommandResponse.errorCode)) {
                Write-Error ('Failed to create Pool [{0}] because of [{1} - {2}]' -f $PoolName, $createCommandResponse.typeKey, $createCommandResponse.message)
                return
            }

            Write-Verbose ("Successfully created Pool [{0}]" -f $PoolName) -Verbose
            return $createCommandResponse
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; New-AzureDevOpsPool -Organization "an-de-ohg-sbi" -Project "AN-Azure-UseCase" -PoolName "ccoe-vmss-usec-ADOAgents" -ServiceConnectionName "serviceconnection-sub-usecase-dev" -SubscriptionId "95eb3f92-5997-4d85-9f2d-d5e9a413da6d" -ResourceGroupName "rg-ccoe-dev-vmss-001" -ScaleSetName "vmss-ccoe-dev-weu-vmss-001"