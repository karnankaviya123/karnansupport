function Remove-AzureDevOpsPool {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $Project,

        [Parameter(Mandatory = $true)]
        [string] $PoolName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pool' 'Get-AzureDevOpsPools.ps1')
    }

    process {
        ################
        #   Get Data   #
        ################
        Write-Verbose ("Check if target Pool [{0}] exists in project {1}" -f $PoolName, $Project) 
        $existing = (Get-AzureDevOpsPools -Organization $Organization -Project $Project) | ?{ $_.Name.ToLowerInvariant() -Eq $PoolName.ToLowerInvariant() }

        if(-Not $existing) {
            Write-Warning ("Pool {0} not found in project {1}, exiting" -f $PoolName, $Project)
            return @{}
        }

        ######################
        #   Remove Pool      #
        ######################
        Write-Verbose ("Removing Pool [{0}] from project {1}" -f $PoolName, $Project) 
        $restInfo = Get-RelativeConfigData -configToken 'RESTPoolDelete'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), $existing.id)
        }
        $response = Invoke-RESTCommand @restInputObject

        if ($response) {
            if ((Get-Member -InputObject $response -MemberType NoteProperty).name -contains 'errorCode') {
                switch($response.typeKey) {
                    'GitIsNotAvailableException' {
                        return @{}
                    }
                    default {
                        Write-Error ("[{0}]: {1}" -f $processes.typeKey, $processes.message)
                    }
                }
            }
        } else {
            # Assume 204, todo: check if it actually is
        }

        return $response
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Remove-AzureDevOpsPool -Organization "an-de-ohg-sbi" -Project "AN-Azure-UseCase" -PoolName "ccoe-vmss-usec-ADOAgents" 