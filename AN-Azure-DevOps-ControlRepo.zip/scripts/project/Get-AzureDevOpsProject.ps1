function Get-AzureDevOpsProject {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $Project
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
    }

    process {
        $restInfo = Get-RelativeConfigData -configToken 'RESTProjectGet'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($Project))
        }
        $response = Invoke-RESTCommand @restInputObject

        if ((Get-Member -InputObject $response -MemberType NoteProperty).name -contains 'errorCode') {
            switch($response.typeKey) {
                'ProjectDoesNotExistWithNameException' {
                    return @{}
                }
                default {
                    Write-Error ("[{0}]: {1}" -f $processes.typeKey, $processes.message)
                }
            }
        }
        return $response
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Get-AzureDevOpsProject -Organization "an-de-ohg-sbi" -Project "/"  # "AN-Azure-UseCase"