function Sync-AzureDevOpsProject {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Project,

        [Parameter(Mandatory = $true)]
        [string] $Organization
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        . (Join-Path $PSScriptRoot 'Get-AzureDevOpsProject.ps1')
        . (Join-Path $PSScriptRoot 'New-AzureDevOpsProject.ps1')
    }

    process {
        ################
        #   Get Data   #
        ################
        $existingProject = Get-AzureDevOpsProject -Organization $Organization -Project $Project

        if (-not $existingProject.id) {   

            ######################
            #   Create Project   #
            ######################

            $updateInputObject = @{
                Organization = $Organization
                Project      = $Project
            }
            if ($PSCmdlet.ShouldProcess(('Project [{0}]' -f $Project), "Create")) {
                return New-AzureDevOpsProject @updateInputObject
            }
        }
        else {
            Write-Verbose ('Project [{0}] already exists in organization [{1}]' -f $Project, $Organization) -Verbose
            return $existingProject.Id
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Sync-AzureDevOpsProject -Organization "an-de-ohg-sbi" -Project "AN-Azure-UseCase"