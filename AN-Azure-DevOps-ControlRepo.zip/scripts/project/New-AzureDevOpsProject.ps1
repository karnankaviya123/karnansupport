function New-AzureDevOpsProject {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $Project,

        [Parameter(Mandatory = $false)]
        [string] $Description,

        [Parameter(Mandatory = $false)]
        [string] $SourceControlType = 'Git',

        [Parameter(Mandatory = $false)]
        [string] $Process = 'Agile',

        [Parameter(Mandatory = $false)]
        [string] $Visibility
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'process' 'Get-DevOpsProcessList.ps1')
    }

    process {

        # Get process ID
        $templateTypeId = (Get-DevOpsProcessList -Organization $Organization | Where-Object { $_.Name -eq $Process }).Id
            
        # Build command
        $body = @{ 
            name         = $Project 
            capabilities = @{
                versioncontrol  = @{
                    sourceControlType = $SourceControlType
                }
                processTemplate = @{
                    templateTypeId = $TemplateTypeId
                }
            }
        }
        if (-not [String]::IsNullOrEmpty($Description)) { $body['description'] = $Description }
        if (-not [String]::IsNullOrEmpty($Visibility)) { $body['visibility'] = $Visibility }

        $restInfo = Get-RelativeConfigData -configToken 'RESTProjectCreate'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($Project))
            body   = ConvertTo-Json $body -Depth 10 -Compress
        }
        
        # Execute command
        if ($PSCmdlet.ShouldProcess(('REST command to create project [{0}]' -f $Project), "Invoke")) {
            $createCommandResponse = Invoke-RESTCommand @restInputObject
            
            if (-not [String]::IsNullOrEmpty($createCommandResponse.errorCode)) {
                Write-Error ('Failed to create project [{0}] because of [{1} - {2}]' -f $Project, $createCommandResponse.typeKey, $createCommandResponse.message)
                return
            }

            Write-Verbose ("Successfully created project [{0}]" -f $Project) -Verbose
            Write-Verbose "Wait for propagation" -Verbose
            Start-Sleep 30
            return $createCommandResponse.id
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; New-AzureDevOpsProject -Organization "an-de-ohg-sbi" -Project "AN-Azure-UseCase" -Description "AN-Azure-UseCase Project"