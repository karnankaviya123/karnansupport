function Sync-AzureDevOpsPipelines {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $RepoName,

        [Parameter(Mandatory = $true)]
        [string] $BranchRef
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'git' 'Get-AzureDevOpsItems.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pipeline' 'Get-AzureDevOpsPipelines.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pipeline' 'New-AzureDevOpsPipeline.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pipeline' 'Run-AzureDevOpsPipeline.ps1')
    }

    process {

        Write-Verbose ("Get files from [{0}] branch of [{1}] repo, that should be created as pipelines" -f $BranchRef, $RepoName) 
        $pipelineFiles = Get-AzureDevOpsItems -Organization $Organization -Project $ProjectName -RepoName $RepoName -BranchRef $BranchRef | ?{
            (-Not $_.isFolder) -And ($_.Path.ToLowerInvariant().EndsWith(".yml") -Or $_.Path.ToLowerInvariant().EndsWith(".yaml")) 
        }

        Write-Verbose ("Check if destination pipelines already created in project [{0}]" -f $ProjectName) 
        $pipelines = Get-AzureDevOpsPipelines -Organization $Organization -Project $ProjectName

        $pipelineFiles | % {
            $PiplineName = [io.path]::GetFileNameWithoutExtension($_.path)
            Write-Verbose ("Create [{0}] pipeline in the [{1}] repo" -f $PiplineName, $RepoName) 
            
            # check existing
            $existing  = $pipelines | ?{ $_.name -Eq $PiplineName }
            if ($existing) {
                Write-Verbose ("Pipeline [{0}] already exists in the [{1}] repo, skipping" -f $PiplineName, $RepoName) 
            } else {
                New-AzureDevOpsPipeline -Organization $Organization -ProjectName $ProjectName -RepoName $RepoName -PipelinePath $_.Path -PipelineName $PiplineName
                Write-Verbose ("Running [{0}] pipeline in the [{1}] repo" -f $PiplineName, $RepoName) 
                Run-AzureDevOpsPipeline -Organization $Organization -ProjectName $ProjectName -PipelineName $PiplineName -BranchRef $BranchRef
            }
        }

    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Sync-AzureDevOpsPipelines -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -RepoName "Bootstrapping" -BranchRef "refs/heads/main"