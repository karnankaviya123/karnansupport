function Run-AzureDevOpsPipeline {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $PipelineName,

        [Parameter(Mandatory = $true)]
        [string] $BranchRef
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path $PSScriptRoot 'Get-AzureDevOpsPipelines.ps1')
    }

    process {
        
        Write-Verbose ("Check if pipeline [{0}] exists in project {1}" -f $PipelineName, $ProjectName) 
        $target = (Get-AzureDevOpsPipelines -Organization $Organization -Project $ProjectName) | ?{ $_.Name.ToLowerInvariant() -Eq $PipelineName.ToLowerInvariant() }
        if(-Not $target) {
            Write-Warning ("Pipeline {0} not found in project {1}, exiting" -f $PipelineName, $ProjectName)
            return ;
        }

        # Build command
        $body = @{ 
            "resources" = @{
                "repositories" = @{
                    "self" = @{
                        "refName" = $BranchRef
                    }
                }
            }
            # "variables": {
            #     "HELLO_WORLD": {
            #         "isSecret": false,
            #         "value": "HelloWorldValue"
            #     }
            # }
        }

        $restInfo = Get-RelativeConfigData -configToken 'RESTPipelineRun'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($ProjectName), [uri]::EscapeDataString($target.id))
            body   = ConvertTo-Json $body -Depth 10 -Compress
        }
        
        # Execute command
        if ($PSCmdlet.ShouldProcess(('REST command to run Pipeline [{0}:{1}] -> [{2}]' -f $Project, $RepoName, $PipelinePath), "Invoke")) {
            $createCommandResponse = Invoke-RESTCommand @restInputObject
            
            if (-not [String]::IsNullOrEmpty($createCommandResponse.errorCode)) {
                Write-Error ('Failed to create Pipeline [{0}] because of [{1} - {2}]' -f $PipelineName, $createCommandResponse.typeKey, $createCommandResponse.message)
                return
            }

            Write-Verbose ("Successfully executed Pipeline [{0}]" -f $PipelineName) -Verbose
            # Write-Verbose "Wait for propagation" -Verbose
            # Start-Sleep 10
            return $createCommandResponse
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Run-AzureDevOpsPipeline -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -PipelineName "Infra.Shared.Example" -BranchRef "refs/heads/main"