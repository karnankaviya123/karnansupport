function Set-AzureDevOpsPipelineVarGroupAccess {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $PipelineName,

        [Parameter(Mandatory = $true)]
        [string] $VarGroupName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'variablegroup' 'Get-AzureDevOpsVariableGroup.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'pipeline' 'Get-AzureDevOpsPipelines.ps1')
    }

    process {
        
        Write-Verbose ("Check if Variable Group [{0}] exists" -f $VarGroupName)
        $existingGroup = Get-AzureDevOpsVariableGroup -Organization $Organization -Project $ProjectName | ?{
            $_.name.ToLowerInvariant() -Eq $VarGroupName
        }

        if (-Not $existingGroup) {
            Write-Verbose ("Variable Group [{0}] not found in project {1}, exiting" -f $VarGroupName, $ProjectName) 
            return ;
        }

        Write-Verbose ("Check if pipeline [{0}] exists in project {1}" -f $PipelineName, $ProjectName) 
        $target = (Get-AzureDevOpsPipelines -Organization $Organization -Project $ProjectName) | ?{ $_.Name.ToLowerInvariant() -Eq $PipelineName.ToLowerInvariant() }
        if(-Not $target) {
            Write-Warning ("Pipeline {0} not found in project {1}, exiting" -f $PipelineName, $ProjectName)
            return ;
        }

        # Build command
        $body = @{
            "resource" = @{}
            "pipelines" = @(
                @{
                    "authorized" = $true
                    "id" = $target.id
                }
            )
        }

        $restInfo = Get-RelativeConfigData -configToken 'RESTPipelineVarGroupGrant'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($ProjectName), [uri]::EscapeDataString($existingGroup.id))
            body   = ConvertTo-Json $body -Depth 10 -Compress
        }
        
        # Execute command
        if ($PSCmdlet.ShouldProcess(('REST command to grant Pipeline [{0}] access to Var Group [{1}]' -f $PipelineName, $VarGroupName), "Invoke")) {
            $createCommandResponse = Invoke-RESTCommand @restInputObject
            
            if (-not [String]::IsNullOrEmpty($createCommandResponse.errorCode)) {
                Write-Error ('Failed to grant access for pipeline [{0}] because of [{1} - {2}]' -f $PipelineName, $createCommandResponse.typeKey, $createCommandResponse.message)
                return
            }

            Write-Verbose ("Successfully grant access for Pipeline [{0}] to Variable Group [{1}]" -f $PipelineName, $VarGroupName) -Verbose
            return $createCommandResponse
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Set-AzureDevOpsPipelineVarGroupAccess -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -PipelineName "Infra.Shared.Example" -VarGroupName "Infra.Shared.Dev"