function Sync-AzureDevOpsServiceEndpointList {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Project,

        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory)]
        [hashtable[]] $ServicePrincipalDetails
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        . (Join-Path $PSScriptRoot 'Get-ServiceConnectionName.ps1')
        . (Join-Path $PSScriptRoot 'Get-AzureDevOpsServiceEndpoint.ps1')
        . (Join-Path $PSScriptRoot 'Set-AzureDevOpsServiceEndpoint.ps1')
        . (Join-Path $PSScriptRoot 'New-AzureDevOpsServiceEndpoint.ps1')
    }

    process {
        ################
        #   Get Data   #
        ################

        # Process all provided service principals
        foreach ($servicePrincipalDetail in $ServicePrincipalDetails) {
            
            $serviceConnectionName = Get-ServiceConnectionName -SubscriptionName $servicePrincipalDetail.subscriptionName
            $matchingEndpoint = $existingEndpoints | Where-Object { $_.name -eq $serviceConnectionName }
            
            if (-not [String]::IsNullOrEmpty($servicePrincipalDetail.applicationSecret)) {
            
                if ($matchingEndpoint) {
                    #######################
                    #   Update Endpoint   #
                    #######################
                    Write-Verbose ('Service connection [{0}] already exists in project [{1}]' -f $serviceConnectionName, $Project) -Verbose

                    $updateInputObject = @{
                        EndpointId            = $matchingEndpoint.id
                        Organization          = $Organization
                        Project               = $Project
                        ServiceConnectionName = $serviceConnectionName
                        SubscriptionId        = $servicePrincipalDetail.subscriptionId
                        SubscriptionName      = $servicePrincipalDetail.subscriptionName
                        TenantId              = $servicePrincipalDetail.tenantId 
                        ApplicationId         = $servicePrincipalDetail.applicationId
                        ApplicationSecret     = $servicePrincipalDetail.applicationSecret
                    }
                    if ($PSCmdlet.ShouldProcess(('Service connection [{0}] for service principal [{1}] pointing at subscription [{2}] in project [{3}]' -f $serviceConnectionName, $servicePrincipalDetail.applicationName, $servicePrincipalDetail.subscriptionName, $Project), "Update")) {
                        Set-AzureDevOpsServiceEndpoint @updateInputObject
                    }
                }
                else {
                    #######################
                    #   Create Endpoint   #
                    #######################
                    Write-Verbose ('Service connection [{0}] does not exist in project [{1}]. Creating new.' -f $serviceConnectionName, $Project) -Verbose

                    $updateInputObject = @{
                        Organization          = $Organization
                        Project               = $Project
                        ServiceConnectionName = $serviceConnectionName
                        SubscriptionId        = $servicePrincipalDetail.subscriptionId
                        SubscriptionName      = $servicePrincipalDetail.subscriptionName
                        TenantId              = $servicePrincipalDetail.tenantId 
                        ApplicationId         = $servicePrincipalDetail.applicationId
                        ApplicationSecret     = $servicePrincipalDetail.applicationSecret
                    }
                    if ($PSCmdlet.ShouldProcess(('Service connection [{0}] for service principal [{1}] pointing at subscription [{2}] in project [{3}]' -f $serviceConnectionName, $servicePrincipalDetail.applicationName, $servicePrincipalDetail.subscriptionName, $Project), "Create")) {
                        New-AzureDevOpsServiceEndpoint @updateInputObject
                    }
                }
            } else {
                Write-Warning ('Skipping creation of service connection [{0}] for service principal [{1}] as no application secret is available.' -f $serviceConnectionName, $servicePrincipalDetail.applicationName)
            }
        }
    }

    end {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)
    }
}