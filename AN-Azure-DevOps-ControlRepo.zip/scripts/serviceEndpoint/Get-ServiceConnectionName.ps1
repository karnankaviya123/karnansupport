<#
.SYNOPSIS
Get the name of the service connection as per the naming convention

.DESCRIPTION
Get the name of the service connection as per the naming convention

.PARAMETER SubscriptionName
Mandatory. The name of the subscription to generate the service connection name for

.EXAMPLE
Get-ServiceConnectionName -SubscriptionName 'mysub'

Generate the service connection name for subscription 'mysub'
#>
function Get-ServiceConnectionName {

    [CmdletBinding()]
    param (
        [Parameter()]
        [string] $SubscriptionName
    )

    return ('{0}-{1}' -f 'serviceconnection', $SubscriptionName)  
}