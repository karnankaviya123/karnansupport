function Set-AzureDevOpsServiceEndpoint {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $EndpointId,

        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $Project,

        [Parameter(Mandatory = $true)]
        [string] $ServiceConnectionName,

        [Parameter(Mandatory = $true)]
        [string] $SubscriptionId,

        [Parameter(Mandatory = $true)]
        [string] $SubscriptionName,

        [Parameter(Mandatory = $true)]
        [string] $TenantId,

        [Parameter(Mandatory = $true)]
        [string] $ApplicationId,

        [Parameter(Mandatory = $true)]
        [string] $ApplicationSecret
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
    }

    process {
        $restInfo = Get-RelativeConfigData -configToken 'RESTConnectionEndpointSet'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($Project), $EndpointId)
            body   = ConvertTo-Json @{
                data          = @{
                    subscriptionId   = $subscriptionId
                    subscriptionName = $SubscriptionName
                    environment      = "AzureCloud"
                    scopeLevel       = 'Subscription'
                    creationMode     = 'Manual'
                }
                name          = $serviceConnectionName
                type          = 'AzureRM'
                authorization = @{
                    parameters = @{
                        tenantid            = $tenantId
                        serviceprincipalid  = $applicationId
                        authenticationType  = "spnKey"
                        serviceprincipalkey = $applicationSecret
                    }
                    scheme     = 'ServicePrincipal'
                }
                url           = 'https://management.azure.com/'
                isReady       = $true                    
            } -Depth 10 -Compress
        }
        if ($PSCmdlet.ShouldProcess(('REST command to update service connection [{0}] for service principal [{1}] pointing at subscription [{2}] in project [{3}]' -f $serviceConnectionName, $servicePrincipalDetail.applicationName, $servicePrincipalDetail.subscriptionName, $azureDevOpsProject), "Invoke")) {
            $result = Invoke-RESTCommand @restInputObject 
            if (-not [String]::IsNullOrEmpty($result.errorCode)) {
                Write-Error ('Failed to update service connection [{0}] because of [{1} - {2}]' -f $serviceConnectionName, $result.typeKey, $result.message)
            }
            else {
                Write-Verbose ('Updated service connection [{0}]' -f $serviceConnectionName) -Verbose
            }
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}