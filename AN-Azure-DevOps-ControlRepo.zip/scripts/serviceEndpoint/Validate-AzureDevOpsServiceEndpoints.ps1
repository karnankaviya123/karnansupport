function Validate-AzureDevOpsServiceEndpoints {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $Project
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        . (Join-Path $PSScriptRoot 'Get-AzureDevOpsServiceEndpoint.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'servicePrincipal' 'Get-AADApplication.ps1')

        if (-Not (Get-MgContext)) {
            Import-Module Az.Accounts
            Import-Module Microsoft.Graph.Authentication


            if ($ENV:AD_APP_TOKEN) {
                $aadAccessToken = $ENV:AD_APP_TOKEN   
            } else {
                $aadAccessToken = (Get-AzAccessToken -ResourceUrl 'https://graph.microsoft.com/').Token
            }
           
            Connect-MgGraph -AccessToken $aadAccessToken -ErrorAction Stop
        }
    }

    process {

        $projects = Get-AzureDevOpsProject -Organization $Organization -Project $Project
        $(if ($projects.id) { $projects } else { $projects.value }) | % {
            Write-Verbose ("Entering project [{0}]" -f $_.name)

            $serviceConnections = Get-AzureDevOpsServiceEndpoint -Organization $Organization -Project $_.id
            $serviceConnections | 
            ? { ($_.type -Eq "AzureRM") -And ($_.authorization.scheme -Eq "ServicePrincipal") -And ($_.authorization.parameters.authenticationType -Eq "spnKey") } | 
            % {
                Write-Verbose ("`tFound service connection [{0}], SP Application Id: [{1}]" -f $_.name, $_.authorization.parameters.serviceprincipalid)

                $application = Get-MgApplication -Filter "AppId eq '$($_.authorization.parameters.serviceprincipalid)'" 
                $application.PasswordCredentials | % {
                    $expires = $_.EndDateTime
                    $expiresIn = New-TimeSpan –Start (GET-DATE) –End $expires
                    Write-Verbose ("`t`tKey [{0}] Expires at [{1}], which is in {2} Days" -f $_.Hint, $expires, [Math]::Round($expiresIn.TotalDays))
                    if ($expiresIn.TotalDays -lt 90) {
                        Write-Warning ("KEY EXPIRES IN {0} DAYS" -f [Math]::Round($expiresIn.TotalDays))
                    }
                }
            }
        }
    }

    end {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; 
Validate-AzureDevOpsServiceEndpoints -Organization "an-de-ohg-sbi" -Project "AN-Azure-Usecase" -Verbose