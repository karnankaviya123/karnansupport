<#
.SYNOPSIS
Get the name of the service principal as per the naming convention

.DESCRIPTION
Get the name of the service principal as per the naming convention

.PARAMETER Project
Mandatory. The name of the project to generate the service principal name with

.PARAMETER SubscriptionName
Mandatory. The name of the subscription to assign the service principal permissions on

.EXAMPLE
Get-ServicePrincipalName -Project 'ALDI' -SubscriptionName 'mySub'

Generate the service principal name for project 'ALDI'
#>
function Get-ServicePrincipalName {

    [CmdletBinding()]
    param (        
        [Parameter()]
        [string] $SubscriptionName
    )

    return ('{0}-{1}' -f 'sp', $SubscriptionName)   
}