<#
.SYNOPSIS
Fetch a application via the REST API

.DESCRIPTION
Fetch a application via the REST API

.PARAMETER objectId
Required. The object ID of the application to fetch

.EXAMPLE
Get-AADApplication -ObjectId '1111-11-11-1-111111'

Get the application that matches object ID '1111-11-11-1-111111'
#>
function Get-AADApplication {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string] $objectId
    )

    $aadAccessToken = (Get-AzAccessToken -ResourceUrl 'https://graph.microsoft.com/').Token

    $inputObject = @{
        Method  = 'GET' 
        Headers = @{ 
            'Authorization' = "Bearer $aadAccessToken"  
        } 
        Uri     = "https://graph.microsoft.com/beta/applications/$objectId"  
    }

    $response = Invoke-RestMethod @inputObject

    if ((Get-Member -InputObject $response -MemberType NoteProperty).name -contains 'errorCode') {
        Write-Error ("[{0}]: {1}" -f $response.typeKey, $response.message)
    }

    return $response
}