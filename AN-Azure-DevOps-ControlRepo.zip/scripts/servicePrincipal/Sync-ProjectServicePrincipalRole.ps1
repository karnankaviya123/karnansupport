<#
.SYNOPSIS
Create or update an Service principal Roles for a given Subscription

.DESCRIPTION
Create or update an Service principal Role for a given Subscription.

.PARAMETER SubscriptionIdentifier
Mandatory. The name of the subscription identifier to update Role for

.PARAMETER servicePrincipalName
Mandatory. The name of the service principal to update Role for

.PARAMETER RoleNames
Mandatory. RBAC role to add or remove

.PARAMETER Action
Mandatory. Either 'add' or 'remove'

.EXAMPLE
Sync-ProjectServicePrincipalRole -SubscriptionIdentifier 'sub-cs-test' -servicePrincipalName 'sp-sub-usecase-dev' -RoleName 'Reader' -Action 'add'

Grant a service principal named 'sp-sub-usecase-dev' Reader role for Subscription named 'sp-sub-usecase-dev'
#>

function Sync-ProjectServicePrincipalRole {
    
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory)]
        [string] $SubscriptionIdentifier,

        [Parameter(Mandatory = $true)]
        [string] $servicePrincipalName,

        [Parameter(Mandatory = $true)]
        [string] $RoleNames,

        [Parameter(Mandatory = $true)]
        [string] $Action
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        # . (Join-Path $PSScriptRoot 'Get-ServicePrincipalName.ps1')
        # . (Join-Path $PSScriptRoot 'Get-AADApplication.ps1')
    }

    process {
        
        #$subscriptionIdentifier = "sub-scngo-int, sub-scngo-prd, sub-scngo-shared"
        
        $formattedIdentifier = $subscriptionIdentifier.Split(',').Trim()
        # # Remove sub (if provided)
        # if ($formattedIdentifier -like "sub-*") {
        #     $formattedIdentifier = $SubscriptionIdentifier.Split('sub-')[1]
        # }
        # # Next in line would be the project name
        # if ($formattedIdentifier -like "*-*") {
        #     $formattedIdentifier = $formattedIdentifier.Split('-')[0]
        # }

        # Get all subscription names containing 'sub-${Project}-'
        #[array] $relevantSubscriptions = Get-AzSubscription | Where-Object { $_.name -like "sub-$formattedIdentifier-*" } 
        [array] $relevantSubscriptions = Get-AzSubscription | Where-Object { $_.name -in $formattedIdentifier } 
        
        if(-not $relevantSubscriptions) {
            Write-Error ('Found no subscriptions that match [{0}]' -f $formattedIdentifier) 
            return
        } else {
            Write-Verbose ('Found [{0}] subscriptions to process: [{1}]' -f $relevantSubscriptions.count, ($relevantSubscriptions.Name -join '|')) -Verbose
        }

        $servicePrincipal = Get-AzADServicePrincipal -DisplayName $servicePrincipalName
        if (-Not $servicePrincipal) {
            Write-Error ('Found no service principal that match the name [{0}]' -f $servicePrincipalName) 
            return
        } else {
            Write-Verbose "Found service principal [$servicePrincipalName]: " -Verbose
            $servicePrincipal | Select-Object -Property Id,AppId,DisplayName | fl
        }

        foreach ($subscription in $relevantSubscriptions) {

            ##########################
            ##   RBAC Permissions   ##
            ##########################
            

            if ($action.Trim().ToLower() -Eq "add") {

                $RoleNames.Split(',').Trim() | % {
                    $RoleName = $_

                    if (-not (Get-AzRoleAssignment -RoleDefinitionName $RoleName -ObjectId $servicePrincipal.Id -Scope ('/subscriptions/{0}' -f $subscription.Id) -ErrorAction 'SilentlyContinue')) {
                        $rbacInputObject = @{
                            RoleDefinitionName = $RoleName
                            ApplicationId      = $servicePrincipal.AppId
                            Scope              = ('/subscriptions/{0}' -f $subscription.Id)
                        }

                        New-AzRoleAssignment @rbacInputObject 
                        Write-Verbose ("Added [{0}] permissions for service principal [{1}] on subscription [{2}]" -f $rbacInputObject.RoleDefinitionName, $servicePrincipalName, $subscription.Name) -Verbose
                    }
                    else {
                        Write-Warning ('Role [{3}] is already assigned to service principal [{0}] on subscription [{1}]' -f $servicePrincipalName, $subscription.name, $RoleName)
                    }
                }
                
            } elseif ($action.Trim().ToLower() -Eq "remove") {
                
                $RoleNames.Split(',').Trim() | % {
                    $RoleName = $_

                    if (Get-AzRoleAssignment -RoleDefinitionName $RoleName -ObjectId $servicePrincipal.Id -Scope ('/subscriptions/{0}' -f $subscription.Id) -ErrorAction 'SilentlyContinue') {
                        $rbacInputObject = @{
                            RoleDefinitionName = $RoleName
                            ObjectId           = $servicePrincipal.Id
                            Scope              = ('/subscriptions/{0}' -f $subscription.Id)
                        }

                        Remove-AzRoleAssignment @rbacInputObject 
                        Write-Verbose ("Removed [{0}] permissions for service principal [{1}] on subscription [{2}]" -f $rbacInputObject.RoleDefinitionName, $servicePrincipalName, $subscription.Name) -Verbose
                    }
                    else {
                        Write-Warning ('Role [{3}] is not assigned to service principal [{0}] on subscription [{1}]' -f $servicePrincipalName, $subscription.name, $RoleName)
                    }
                }
                
            } else {
                Write-Warning "Action [$action] is not implemented. Please use 'add' or 'remove'"
            }
        }      
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}