<#
.SYNOPSIS
Create or update an Service principal for a given SubscriptionIdentifier team

.DESCRIPTION
Create or update an Service principal for a given SubscriptionIdentifier team. The principal is also given permissions to the given subscription.

.PARAMETER SubscriptionIdentifier
Mandatory. The name of the subscription identifier (containing the team identifier) to create the service principal for

.PARAMETER MaximumDaysToSecretExpiry
Optional. The maximum number of days a secret would not be considered for a refresh

.PARAMETER PrincipalsIdsToCheck
Optional. Principals IDs to potentially renew the secret of

.EXAMPLE
Sync-ProjectServicePrincipal -SubscriptionIdentifier 'sub-ALDI'

Create a service principal for -SubscriptionIdentifier team 'sub-ALDI' that is granted permissions to all subscriptions that match 'sub-aldi'
#>
function Sync-ProjectServicePrincipal {
    
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory)]
        [string] $SubscriptionIdentifier,

        [Parameter(Mandatory = $false)]
        [string[]] $PrincipalsIdsToCheck,

        [Parameter(Mandatory = $false)]
        [int] $maximumDaysToSecretExpiry = 7,

        [Parameter(Mandatory = $false)]
        [string] $defaultSecretDescriptionName = 'AzureDevOpsServiceConnection',

        [Parameter(Mandatory = $false)]
        [string] $ddosAADGroupId = 'c38caa12-2e6e-4404-81f2-28328ed8cf6b',

        [Parameter(Mandatory = $false)]
        [string] $agentsSubscriptionId = '631fd8ad-eadc-4ee8-a287-ebff6bd66bed',

        [Parameter(Mandatory = $false)]
        [string] $agentsResourceGroupId = 'azdevops-agents-images',

        [Parameter(Mandatory = $false)]
        [string] $agentsGalleryName = 'pipelineagents_image_gallery'
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path $PSScriptRoot 'Get-ServicePrincipalName.ps1')
        . (Join-Path $PSScriptRoot 'Get-AADApplication.ps1')
    }

    process {
        
        #$subscriptionIdentifier = "sub-scngo-int, sub-scngo-prd, sub-scngo-shared"
        
        $formattedIdentifier = $subscriptionIdentifier.Split(',').Trim()
        # # Remove sub (if provided)
        # if ($formattedIdentifier -like "sub-*") {
        #     $formattedIdentifier = $SubscriptionIdentifier.Split('sub-')[1]
        # }
        # # Next in line would be the project name
        # if ($formattedIdentifier -like "*-*") {
        #     $formattedIdentifier = $formattedIdentifier.Split('-')[0]
        # }

        # Get all subscription names containing 'sub-${Project}-'
        #[array] $relevantSubscriptions = Get-AzSubscription | Where-Object { $_.name -like "sub-$formattedIdentifier-*" } 
        [array] $relevantSubscriptions = Get-AzSubscription | Where-Object { $_.name -in $formattedIdentifier } 
        
        if(-not $relevantSubscriptions) {
            Write-Verbose ('Found no subscriptions that match [{0}]' -f $formattedIdentifier) -Verbose
            return
        } else {
            Write-Verbose ('Found [{0}] subscriptions to process: [{1}]' -f $relevantSubscriptions.count, ($relevantSubscriptions.Name -join '|')) -Verbose
        }

        # Create one service connection each
        $principalDetails = @()
        foreach ($subscription in $relevantSubscriptions) {

            $servicePrincipalName = Get-ServicePrincipalName -SubscriptionName $subscription.name

            ##############################
            ##   AZURE AD APPLICATION   ##
            ##############################

            $createNewSecret = $false
            if (-not ($servicePrincipal = Get-AzADServicePrincipal -DisplayName $servicePrincipalName)) {
                # Service principal does not exist
                # --------------------------------
                if ($PSCmdlet.ShouldProcess(('Service principal [{0}]' -f $servicePrincipalName), "Create")) {
                    $servicePrincipal = New-AzADServicePrincipal -DisplayName $servicePrincipalName
                    
                    # Removing default secret 
                    if ($createdSecret = Get-AzADAppCredential -ApplicationId $servicePrincipal.AppId) {
                        $null = Remove-AzADAppCredential -ApplicationId $servicePrincipal.AppId -KeyId $createdSecret.KeyId
                    }          
                    $createNewSecret = $true

                    Write-Verbose "Created service principal [$servicePrincipalName]" -Verbose
                }
            }
            else {
                # Service principal already exists
                # --------------------------------
                Write-Verbose "Service principal [$servicePrincipalName] already exists" -Verbose

                if ($PrincipalsIdsToCheck -notcontains $servicePrincipal.AppId) {
                    # No matching service connection exists in ADO. Hence we must generate a new secret   
                    $createNewSecret = $true
                }
                else { 
                    # The service connection already exists in ADO, but we have to check if the secret must be renewed  
                    if ($currentSecrets = Get-AzADAppCredential -ApplicationId $servicePrincipal.AppId) {
                        Write-Verbose ('Found [{0}] secrets on service principal [{1}]' -f $currentSecrets.Count, $servicePrincipal.DisplayName) -Verbose

                        $relevantSecrets = $currentSecrets | Where-Object { 
                            ($_.CustomKeyIdentifier).Count -ne 0 
                        } | Where-Object {
                            [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String([System.Convert]::ToBase64String($_.CustomKeyIdentifier))) -eq $defaultSecretDescriptionName
                        }
                        
                        Write-Verbose ('Filtered secrets down to [{0}] Azure DevOps secrets on service principal [{1}]' -f $relevantSecrets.Count, $servicePrincipal.DisplayName)
                        
                        # Service principal has secrets. Checking validity.
                        $latestDate = ($relevantSecrets.EndDateTime | Measure-Object -Maximum).Maximum
                        $currentDate = Get-Date
                        $daysToExpiry = (NEW-TIMESPAN -Start $currentDate -End $latestDate).Days
                        if ($daysToExpiry -lt $MaximumDaysToSecretExpiry) {
                            Write-Verbose ('The current secret would expire in less than [{0}] days. Refresh required' -f $daysToExpiry) -Verbose
                            $createNewSecret = $true
                        }
                        else {
                            Write-Verbose "The secret with the most distant expiry date is valid for another [$daysToExpiry] days" -Verbose
                        }
                        
                        # Cleanup expired secrets
                        $expiredSecrets = $relevantSecrets | Where-Object {
                            (NEW-TIMESPAN -Start $currentDate -End $_.EndDateTime ).Days -lt 0 
                        }
                        if ($expiredSecrets.Count -gt 0) {
                            Write-Verbose ('Found [{0}] expired secrets to remove' -f $expiredSecrets.count) -Verbose
                            foreach ($expiredSecret in $expiredSecrets) {
                                $null = Remove-AzADAppCredential -ApplicationId $servicePrincipal.AppId -KeyId $expiredSecret.KeyId
                                $secretName = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String([System.Convert]::ToBase64String($expiredSecret.CustomKeyIdentifier)))
                                Write-Verbose ('Removed secret [{0}] with id [{1}]' -f $secretName, $expiredSecret.KeyId) -Verbose
                            }    
                        }
                    }
                }
            }

            if ($createNewSecret) {
                # Requires permission 'Application Administrator' / Custom role with 'Application/OwnedBy'
                # Add custom secret (with default end date: today + 2 years)
                $newSecretInputObject = @{
                    ApplicationId       = $servicePrincipal.AppId
                    CustomKeyIdentifier = ([System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes(($defaultSecretDescriptionName))))
                }
                Write-Verbose ('Creating new secret for service principal [{0}]' -f $servicePrincipalName) -Verbose
                $newSecret = New-AzADAppCredential @newSecretInputObject
                $applicationSecret = $newSecret.SecretText
            }

            ##########################
            ##   RBAC Permissions   ##
            ##########################
            if (-not (Get-AzRoleAssignment -RoleDefinitionName 'Owner' -ObjectId $servicePrincipal.Id -Scope ('/subscriptions/{0}' -f $subscription.Id) -ErrorAction 'SilentlyContinue')) {
                $rbacInputObject = @{
                    RoleDefinitionName = 'Owner' 
                    ApplicationId      = $servicePrincipal.AppId
                    Scope              = ('/subscriptions/{0}' -f $subscription.Id)
                }
                if ($PSCmdlet.ShouldProcess(('Role assignment for service principal [{0}] on subscription [{1}]' -f $servicePrincipalName, $subscription.name), "Add")) {
                    $null = New-AzRoleAssignment @rbacInputObject 
                    Write-Verbose ("Set [{0}] permissions for service principal [{1}] on subscription [{2}]" -f $rbacInputObject.RoleDefinitionName, $servicePrincipalName, $subscription.Name) -Verbose
                }
            }
            else {
                Write-Verbose ('Role [Owner] is already assigned to service principal [{0}] on subscription [{1}]' -f $servicePrincipalName, $subscription.name) -Verbose
            }

            #################################################################################
            ##   Grant Service Connection Reader role on the shared Compute Gallery        ##
            #################################################################################
            $agentsScope = "/subscriptions/$agentsSubscriptionId/resourceGroups/$agentsResourceGroupId/providers/Microsoft.Compute/galleries/$agentsGalleryName"
            if (-not (Get-AzRoleAssignment -RoleDefinitionName 'Reader' -ObjectId $servicePrincipal.Id -Scope $agentsScope -ErrorAction 'SilentlyContinue')) {
                $rbacInputObject = @{
                    RoleDefinitionName = 'Reader' 
                    ApplicationId      = $servicePrincipal.AppId
                    Scope              = $agentsScope
                }
                if ($PSCmdlet.ShouldProcess(('Role assignment for service principal [{0}] on scope [{1}]' -f $servicePrincipalName, $agentsScope), "Add")) {
                    $null = New-AzRoleAssignment @rbacInputObject 
                    Write-Verbose ("Set [{0}] permissions for service principal [{1}] on scope [{2}]" -f $rbacInputObject.RoleDefinitionName, $servicePrincipalName, $agentsScope) -Verbose
                }
            }
            else {
                Write-Verbose ('Role [Reader] is already assigned to service principal [{0}] on resource [{1}]' -f $servicePrincipalName, $agentsScope) -Verbose
            }

            #################################################################################
            ##   Add Service Connection to AAD Group for DDoS Protection Plan Permissions  ##
            #################################################################################
            try {
                $ddosAADGroup = Get-AzADGroup -ObjectId $ddosAADGroupId
            }
            catch {
                Write-Error "Could not find AAD group [$ddosAADGroupId]"
                exit 1
            }

            if (-not (Get-AzADGroupMember -GroupObjectId $ddosAADGroup.id | Where-Object {$_.id -eq $($servicePrincipal.id)})){
                $null = Add-AzADGroupMember -TargetGroupObjectId $ddosAADGroup.id -MemberObjectId $servicePrincipal.Id
                Write-Verbose ("Added service principal [{0}] to AAD Group [{1}]" -f $servicePrincipalName, $ddosAADGroup.id) -Verbose
            }
            else {
                Write-Verbose ('Service principal [{0}] is already a member of AAD Group [{1} ; {2}]' -f $servicePrincipalName, $ddosAADGroup.DisplayName, $ddosAADGroup.id) -Verbose
            }
            ###

            $newDetail = @{
                subscriptionName = $subscription.name
                subscriptionId   = $subscription.subscriptionId
                tenantId         = $subscription.TenantId
                applicationName  = $servicePrincipalName
                applicationId    = $servicePrincipal.AppId
            }
            if (-not [String]::IsNullOrEmpty($applicationSecret)) {
                $newDetail['applicationSecret'] = $applicationSecret
            }
            $principalDetails += $newDetail
        }      
        return $principalDetails
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}