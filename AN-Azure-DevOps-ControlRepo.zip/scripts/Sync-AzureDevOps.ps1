function Sync-AzureDevOps {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $DevOpsProjectName,

        [Parameter(Mandatory = $false)]
        [hashtable[]] $ServicePrincipalDetails = @(),
        
        [Parameter(Mandatory = $false)]
        [bool] $deployProject = $true,

        [Parameter(Mandatory = $false)]
        [bool] $deployServiceConnections = $true
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path $PSScriptRoot 'project' 'Sync-AzureDevOpsProject.ps1')
        . (Join-Path $PSScriptRoot 'serviceEndpoint' 'Sync-AzureDevOpsServiceEndpointList.ps1')
    }

    process {
        if ($deployProject) {
            #######################
            #   Process Project   #
            #######################
            $projectInputObject = @{
                Project      = $DevOpsProjectName
                Organization = $Organization
            }
            if ($PSCmdlet.ShouldProcess(('Azure DevOps Project [{0}] in organization [{1}]' -f $DevOpsProjectName, $Organization), 'Sync')) {
                $null = Sync-AzureDevOpsProject @projectInputObject
            }
        }

        if ($deployServiceConnections -and $ServicePrincipalDetails.Count -gt 0) {
            ##################################
            #   Process Service Connection   #
            ##################################
            $connectionInputObject = @{
                Project                 = $DevOpsProjectName
                Organization            = $Organization
                ServicePrincipalDetails = $ServicePrincipalDetails
            }
            if ($PSCmdlet.ShouldProcess(('[{0}] Service Endpoints for Azure DevOps Project [{1}|{2}]' -f $ServicePrincipalDetails.Count, $DevOpsProjectName, $Organization), 'Sync')) {
                $null = Sync-AzureDevOpsServiceEndpointList @connectionInputObject
            }
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}