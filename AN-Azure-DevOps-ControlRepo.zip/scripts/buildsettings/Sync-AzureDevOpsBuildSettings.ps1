
function Sync-AzureDevOpsBuildSettings {

    [CmdletBinding()]
    [OutputType('System.Object[]')]
    param(
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'buildsettings' 'Get-AzureDevOpsBuildSettings.ps1')
    }

    process {

        Write-Debug ("Check if [{0}] project settings are set up right" -f $ProjectName)
        $settings = Get-AzureDevOpsBuildSettings -Organization $Organization -ProjectName $ProjectName
        if (($settings.enforceJobAuthScope -Eq $FALSE) -And ($settings.enforceReferencedRepoScopedToken -Eq $FALSE))
        {
            Write-Debug ("`tenforceJobAuthScope = `$FALSE, enforceReferencedRepoScopedToken = `$FALSE; no changes needed")
            return;
        }

        $settings.enforceJobAuthScope = $FALSE
        $settings.enforceReferencedRepoScopedToken = $FALSE
        
        Write-Debug ("Updating [{0}] project settings: {1}" -f $ProjectName, (ConvertTo-Json $settings -Compress))

        $restInfo = Get-RelativeConfigData -configToken 'RESTBuildSettingsUpdate'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($ProjectName))
            body   = ConvertTo-Json $settings -Depth 10 -Compress
        }

        # Execute command
        if ($PSCmdlet.ShouldProcess(('REST command to update settings in project [{0}]' -f $Project), "Invoke")) {
            $createCommandResponse = Invoke-RESTCommand @restInputObject
            
            if (-not [String]::IsNullOrEmpty($createCommandResponse.errorCode)) {
                Write-Error ('Failed to update settings for project [{0}] because of [{1} - {2}]' -f $ProjectName, $createCommandResponse.typeKey, $createCommandResponse.message)
                return
            }

            Write-Verbose ("Successfully updated project build settings [{0}]" -f $ProjectName) -Verbose
            return $createCommandResponse
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Sync-AzureDevOpsBuildSettings -Organization "an-de-ohg-sbi" -ProjectName "AI Queueing"