
function Get-AzureDevOpsBuildSettings {

    [CmdletBinding()]
    [OutputType('System.Object[]')]
    param(
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
    }

    process {

        $restInfo = Get-RelativeConfigData -configToken 'RESTBuildSettingsGet'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($ProjectName))
        }
        $settings = Invoke-RESTCommand @restInputObject

        if ($settings.errorCode) {
            Write-Error ("[{0}]: {1}" -f $settings.typeKey, $settings.message)
        }
        if ($settings) {
            return $settings
        }
        else {
            return @()
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Get-AzureDevOpsBuildSettings -Organization "an-de-ohg-sbi" -ProjectName "AI Queueing"
