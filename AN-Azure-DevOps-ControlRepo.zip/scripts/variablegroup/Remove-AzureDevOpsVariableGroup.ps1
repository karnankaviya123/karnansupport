function Remove-AzureDevOpsVariableGroup {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $VarGroupName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'project' 'Get-AzureDevOpsProject.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'variablegroup' 'Get-AzureDevOpsVariableGroup.ps1')

    }

    process {
        ################
        #   Get Data   #
        ################
        Write-Verbose ("Check if Variable Group [{0}] exists" -f $VarGroupName)
        $existingGroup = Get-AzureDevOpsVariableGroup -Organization $Organization -Project $ProjectName | ?{
            $_.name.ToLowerInvariant() -Eq $VarGroupName
        }
        
        if(-Not $existingGroup) {
            Write-Warning ("Variable Group {0} not found in project {1}, exiting" -f $VarGroupName, $ProjectName)
            return @{}
        }

        # Get project reference
        Write-Verbose ("Check if destination project [{0}] exists in organisation {1}" -f $ProjectName, $Organization) 
        $Project = Get-AzureDevOpsProject -Organization $Organization -Project $ProjectName
        if (-Not $Project) {
            Write-Error ("Project {1} not found in organisation {0}" -f $Organization, $ProjectName)
            return ;
        }

        ######################
        #   Remove Group     #
        ######################
        Write-Verbose ("Removing Variable Group [{0}] from project {1}" -f $VarGroupName, $ProjectName) 
        $restInfo = Get-RelativeConfigData -configToken 'RESTVarGroupDelete'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($Project.id), $existingGroup.id)
        }
        $response = Invoke-RESTCommand @restInputObject

        if ($response) {
            if ((Get-Member -InputObject $response -MemberType NoteProperty).name -contains 'errorCode') {
                switch($response.typeKey) {
                    'GitIsNotAvailableException' {
                        return @{}
                    }
                    default {
                        Write-Error ("[{0}]: {1}" -f $processes.typeKey, $processes.message)
                    }
                }
            }
        } else {
            # Assume 204, todo: check if it actually is
        }

        return $response
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}
 
# $DebugPreference = 'Continue'; Remove-AzureDevOpsVariableGroup -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -VarGroupName "Infra.Shared"