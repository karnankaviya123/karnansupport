function Sync-AzureDevOpsVariableGroups {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $VarGroupName,

        [Parameter(Mandatory = $false)]
        [string] $VarGroupDesc = "Created by Automation",

        [Parameter(Mandatory = $false)]
        [hashtable] $Variables = @{
            "dummy" = "" # at least one must be added at creation
        }
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'git' 'Get-AzureDevOpsItems.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'variablegroup' 'Get-AzureDevOpsVariableGroup.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'variablegroup' 'New-AzureDevOpsVariableGroup.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'variablegroup' 'Remove-AzureDevOpsVariableGroup.ps1')
    }

    process {

        Write-Verbose ("Check if Variable Group [{0}] exists" -f $VarGroupName)
        $existingGroup = Get-AzureDevOpsVariableGroup -Organization $Organization -Project $ProjectName | ?{
            $_.name.ToLowerInvariant() -Eq $VarGroupName
        }
        
        ## DEBUG ONLY: delete group if already exists
        # if ($existingGroup) {
        #     Write-Verbose ("Variable Group {0} already exists in project {1}, removing first" -f $VarGroupName, $ProjectName)
        #     Remove-AzureDevOpsVariableGroup -Organization $Organization -Project $ProjectName -VarGroupName $VarGroupName
        #     $existingGroup = $NULL
        # }

        if ($existingGroup) {
            Write-Verbose ("Variable Group [{0}] already exists in the [{1}] project, skipping creation" -f $VarGroupName, $ProjectName) 
        } else {
            Write-Verbose ("Creating [{0}] Variable Group in the [{1}] project" -f $VarGroupName, $ProjectName) 
            New-AzureDevOpsVariableGroup -Organization $Organization -ProjectName $ProjectName -VarGroupName $VarGroupName -VarGroupDesc $VarGroupDesc -Variables $Variables
        }
        
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Sync-AzureDevOpsVariableGroups -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -VarGroupName "Infra.Shared" 