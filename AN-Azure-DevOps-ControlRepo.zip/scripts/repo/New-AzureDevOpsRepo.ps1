function New-AzureDevOpsRepo {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $false)]
        [string] $SourceProjectName = "AN-Azure-DevOps-ControlRepo",

        [Parameter(Mandatory = $false)]
        [string] $SourceRepoName = "Bootstrapping",

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $RepoName,

        [Parameter(Mandatory = $true)]
        [string] $BranchRef
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'project' 'Get-AzureDevOpsProject.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'repo' 'Get-AzureDevOpsRepo.ps1')

    }

    process {

        Write-Verbose ("Check if destination project [{0}] exists in organisation {1}" -f $ProjectName, $Organization) 
        $Project = Get-AzureDevOpsProject -Organization $Organization -Project $ProjectName
        if (-Not $Project) {
            Write-Error ("Project {0} not found in organisation {1}" -f $Organization, $ProjectName)
            return ;
        }

        Write-Verbose ("Check if destination repo [{0}] exists in project {1}" -f $RepoName, $ProjectName) 
        $existingRepo = (Get-AzureDevOpsRepo -Organization $Organization -Project $ProjectName) | ?{ $_.Name.ToLowerInvariant() -Eq $RepoName.ToLowerInvariant() }
        if($existingRepo) {
            Write-Warning ("Repo {0} already exists in project {1}, exiting" -f $RepoName, $ProjectName)
            return $existingRepo
        }

        Write-Verbose ("Check if source project [{0}] exists in organisation {1}" -f $SourceProjectName, $Organization) 
        $SourceProject = Get-AzureDevOpsProject -Organization $Organization -Project $SourceProjectName
        if (-Not $SourceProject) {
            Write-Error ("Project {0} not found in organisation {1}" -f $Organization, $SourceProjectName)
            return ;
        }

        Write-Verbose ("Check if source repo [{0}] exists in project {1}" -f $SourceRepoName, $SourceProjectName) 
        $SourceRepo = (Get-AzureDevOpsRepo -Organization $Organization -Project $SourceProjectName) | ?{ $_.Name.ToLowerInvariant() -Eq $SourceRepoName.ToLowerInvariant() }
        if(-Not $SourceRepo) {
            Write-Warning ("Repo {0} not found in project {1}, exiting" -f $SourceRepoName, $SourceProjectName)
            return ;
        }

        # Build command
        $body = @{ 
            "name" = $RepoName
            "project" = @{
                "id" = $Project.id
                "name" = $Project.Name
            }
            "parentRepository" = @{
                "id" = $SourceRepo.Id
                "name" = $SourceRepo.Name
                "project" = @{
                    "id" = $SourceProject.Id
                    "name" = $SourceProject.Name
                }
            }
        }

        $restInfo = Get-RelativeConfigData -configToken 'RESTRepoCreate'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($ProjectName), [uri]::EscapeDataString($BranchRef))
            body   = ConvertTo-Json $body -Depth 10 -Compress
        }
        
        # Execute command
        if ($PSCmdlet.ShouldProcess(('REST command to create forked repo [{0}:{1}] -> [{2}:{3}]' -f $SourceProject, $SourceRepoName, $Project, $RepoName), "Invoke")) {
            $createCommandResponse = Invoke-RESTCommand @restInputObject
            
            if (-not [String]::IsNullOrEmpty($createCommandResponse.errorCode)) {
                Write-Error ('Failed to create repo [{0}] because of [{1} - {2}]' -f $SourceRepoName, $createCommandResponse.typeKey, $createCommandResponse.message)
                return
            }

            Write-Verbose ("Successfully created repo [{0}]" -f $RepoName) -Verbose
            return $createCommandResponse
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; New-AzureDevOpsRepo -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -RepoName "Bootstrapping" -BranchRef "refs/heads/main"