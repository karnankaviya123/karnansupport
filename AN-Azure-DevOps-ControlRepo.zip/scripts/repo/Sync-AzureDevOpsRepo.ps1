function Sync-AzureDevOpsRepo {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $false)]
        [string] $SourceProjectName = "AN-Azure-DevOps-ControlRepo",

        [Parameter(Mandatory = $false)]
        [string] $SourceRepoName = "Bootstrapping",

        [Parameter(Mandatory = $true)]
        [string] $ProjectName,

        [Parameter(Mandatory = $true)]
        [string] $RepoName,

        [Parameter(Mandatory = $true)]
        [string] $BranchRef
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        . (Join-Path $PSScriptRoot 'Get-AzureDevOpsRepo.ps1')
        . (Join-Path $PSScriptRoot 'New-AzureDevOpsRepo.ps1')
        . (Join-Path $PSScriptRoot 'Remove-AzureDevOpsRepo.ps1')
    }

    process {
        ################
        #   Get Data   #
        ################

        Write-Verbose ("Check if destination repo [{0}] exists in project {1}" -f $RepoName, $ProjectName) 
        $existingRepo = (Get-AzureDevOpsRepo -Organization $Organization -Project $ProjectName) | ?{ $_.Name.ToLowerInvariant() -Eq $RepoName.ToLowerInvariant() }
        # if($existingRepo) {
        #     Write-Verbose ("Repo {0} already exists in project {1}, removing first" -f $RepoName, $ProjectName)
        #     Remove-AzureDevOpsRepo -Organization $Organization -Project $ProjectName -RepoName $RepoName
        #     $existingRepo = $NULL
        # }

        if (-not $existingRepo) {   

            ######################
            #   Create Fork Repo #
            ######################

            $createInputObject = @{
                Organization        = $Organization
                SourceProjectName   = $SourceProjectName
                ProjectName         = $ProjectName
                SourceRepoName      = $SourceRepoName
                RepoName            = $RepoName
                BranchRef           = $BranchRef
            }
            if ($PSCmdlet.ShouldProcess(('Repo [{0}]' -f $RepoName), "Create")) {
                return New-AzureDevOpsRepo @createInputObject
            }
        }
        else {
            Write-Verbose ('Repo [{0}] already exists in project [{1}]' -f $RepoName, $Project) -Verbose
            return $existingRepo
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Sync-AzureDevOpsRepo -Organization "an-de-ohg-sbi" -ProjectName "AN-Azure-UseCase" -RepoName "Bootstrapping" -BranchRef "refs/heads/main"