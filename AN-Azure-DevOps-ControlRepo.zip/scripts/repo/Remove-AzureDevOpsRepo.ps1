function Remove-AzureDevOpsRepo {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Organization,

        [Parameter(Mandatory = $true)]
        [string] $Project,

        [Parameter(Mandatory = $true)]
        [string] $RepoName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Load helper
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Get-RelativeConfigData.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'shared' 'Invoke-RESTCommand.ps1')
        . (Join-Path (Split-Path $PSScriptRoot -Parent) 'repo' 'Get-AzureDevOpsRepo.ps1')
    }

    process {
        ################
        #   Get Data   #
        ################
        Write-Verbose ("Check if target repo [{0}] exists in project {1}" -f $RepoName, $Project) 
        $existingRepo = (Get-AzureDevOpsRepo -Organization $Organization -Project $Project) | ?{ $_.Name.ToLowerInvariant() -Eq $RepoName.ToLowerInvariant() }

        if(-Not $existingRepo) {
            Write-Warning ("Repo {0} not found in project {1}, exiting" -f $RepoName, $Project)
            return @{}
        }

        ######################
        #   Remove Repo      #
        ######################
        Write-Verbose ("Removing repo [{0}] from project {1}" -f $RepoName, $Project) 
        $restInfo = Get-RelativeConfigData -configToken 'RESTRepoDelete'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($Project), $existingRepo.id)
        }
        $response = Invoke-RESTCommand @restInputObject

        if ($response) {
            if ((Get-Member -InputObject $response -MemberType NoteProperty).name -contains 'errorCode') {
                switch($response.typeKey) {
                    'GitIsNotAvailableException' {
                        return @{}
                    }
                    default {
                        Write-Error ("[{0}]: {1}" -f $processes.typeKey, $processes.message)
                    }
                }
            }
        } else {
            # Assume 204, todo: check if it actually is
        }

        Write-Verbose ("Removing repo [{0}] from project's Recycle Bin" -f $RepoName) 
        $restInfo = Get-RelativeConfigData -configToken 'RESTRepoPurge'
        $restInputObject = @{
            method = $restInfo.method
            uri    = '"{0}"' -f ($restInfo.uri -f [uri]::EscapeDataString($Organization), [uri]::EscapeDataString($Project), $existingRepo.id)
        }
        $response = Invoke-RESTCommand @restInputObject

        if ($response) {
            if ((Get-Member -InputObject $response -MemberType NoteProperty).name -contains 'errorCode') {
                switch($response.typeKey) {
                    'GitIsNotAvailableException' {
                        return @{}
                    }
                    default {
                        Write-Error ("[{0}]: {1}" -f $processes.typeKey, $processes.message)
                    }
                }
            }
        } else {
            # Assume 204, todo: check if it actually is
        }

        return $response
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}

# $DebugPreference = 'Continue'; Remove-AzureDevOpsRepo -Organization "an-de-ohg-sbi" -Project "AN-Azure-UseCase" -RepoName "Bootstrapping"