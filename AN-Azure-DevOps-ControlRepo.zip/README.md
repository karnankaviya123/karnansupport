# Azure DevOps Project generation

This repository provides you with the capabilities to deploy 
- Service Principals that are granted access to all subscriptions that match the provided project name (`"sub-$Project-*"`)
- Service Principals are also add to the AAD-Group `AZR.AA.ALL.Security.DDoSPlan.Join.PROD`. This group allows the SPNs to create VNets which are assigned to the central DDoSPlan
- An Azure DevOps project 
- Service Endpoints for all Service Principals created before. 
  > **Note:** The principal used to deploy the resources has currently no permissions to add secrets to already existing service principals. For this reason, it will not be able to create service connections for existing principals. This feature is however already implemented and can be enable once the deploying principal is given the required permissions.

# Usage

The described functionality is provided via the pipeline `AN-Azure-DevOps-ControlRepo`. The pipeline is written in a way that you can run in as many times as you want without breaking it (unless you attempt to create a new service connection for an already existing service principal). 

Upon triggering, the pipeline provides you with the following parameters to configure:

![PipelineSelect](docs/pipelineTrigger.png =40%x)

| Parameter | Description |
| - | - |
| `A subscription/team identifier` | An identifier for one of the teams subscriptions. Can be for example `sub-team-prd` / `sub-team` / `team`. Will be used to identify the team's identifier to fetch all subscriptions from it |
| `The name of the Azure DevOps to create` | The name of the Azure DevOps project to create the project in. Will be created in the `an-de-ohg-sbi` organization. |
| `Deploy service principals` | A switch to toggle the deployment of service principals on/off. Defaults to `true`. |
| `Deploy Azure DevOps project` | A switch to toggle the deployment of the Azure DevOps project on/off. Defaults to `true`. |
| `Deploy service connections` | A switch to toggle the deployment of the service connections on/off. Defaults to `true`. |

When executing the pipeline you should usually not be required to do more than providing the `The name of the project to create the Azure DevOps project for`.

# Additional remarks

- Names
  - The service principals (if not existing) will be created for each subscription with name `sp-<subscriptionName>`  
  - The Azure DevOps name will be the one provided via the pipeline
  - The Azure DevOps service connection (if not existing) will be created for each subscription with name `serviceconnection-<subscriptionName>`  


Please take not of the following considerations:
- On order for the deploying service principal to create new Azure DevOps project (via the `'$(System.AccessToken)'`), you must ensure two things:
  - You have to enable the project with the deploying pipeline to operate outside its project current my switching the corresponding toggle in the project settings `'off'`:
  ![PipelineSelect](docs/setProPermissions.png)
  - The `Project Collection Build Service` **User** must be granted `'Allow'` permissions for `'Create new projects'` in the organization settings:
  ![PipelineSelect](docs/setOrgPermission.png)