
<#
    .SYNOPSIS
    Creates 3 Azure AD Groups for default permissions set

    .DESCRIPTION
    Creates 3 Azure AD Groups for  default roles: Reader, Contributor, Owner

    .PARAMETER groupNameTemplate
    Mandatory. Template that will be filled out to get group names

    .EXAMPLE
    ./tools/Scripts/Create-LZGroups.ps1 -groupNameTemplate "AZR.WW.MST.contoso.sub.DEV.{0}" -WhatIf:$true
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $groupNameTemplate
)

$groupRoles = @('Reader','Contributor','Owner')
$groupNamesToDisplay = New-Object System.Collections.ArrayList

# Display group names for operations team, so it will be easier to find them in AAD
$groupNamesToDisplay.Add("Group names:") | Out-null
foreach ($roleName in $groupRoles) {
    $groupNamesToDisplay.Add("`n$groupNameTemplate" -f $roleName) | Out-null
}
Write-Verbose "$groupNamesToDisplay`n`n" -Verbose

# Create groups
foreach ($roleName in $groupRoles) {
    $groupName = $groupNameTemplate -f $roleName

    Write-Verbose "Check if group '$groupName' already exists" -Verbose

    # Check if group exists and create

    $group = Get-MgGroup -Filter "DisplayName eq '$groupName'"
    if ($group) {
        Write-Verbose  "Group already exists: $($group.Id)" -Verbose
    } else {
        if ($PSCmdlet.ShouldProcess("Creating Group: '$groupName'", "Invoke")) {
            Write-Verbose  "Creating Group: $groupName" -Verbose

            $group = New-MgGroup `
            -DisplayName $groupName `
            -MailNickName $groupName `
            -SecurityEnabled `
            -MailEnabled:$False
            # -Owners @($ownerId) `
            # -Members @($ownerId) `
            
        } else {
            Write-Verbose  "Would create Group: $groupName" -Verbose
        } 
    }

    if ($group) {
        $group | Format-List Id, DisplayName, Description
    }

}
