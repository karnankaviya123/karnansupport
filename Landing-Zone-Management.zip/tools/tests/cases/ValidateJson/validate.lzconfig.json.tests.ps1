
$lzconfig = $(Get-item "$PSScriptRoot/../../../../lzconfig.json").FullName
$lzconfigSchema = $(Get-item "$PSScriptRoot/../../lzconfig.schema.json").FullName
write-host $lzconfig

Describe "Config Validation" {
    Context "JSON Schema" {
        $lzconfigJson = Get-Content -Raw $lzconfig
        $lzconfigSchemaJson = Get-Content -Raw $lzconfigSchema
        It "The Config should be valid by schema" -TestCases @{lzconfigJson=$lzconfigJson;lzconfigSchemaJson=$lzconfigSchemaJson} {
            Test-Json $lzconfigJson -Schema $lzconfigSchemaJson | Should -BeTrue
        }
    }
}