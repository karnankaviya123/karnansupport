param (
        [Parameter(Mandatory = $false)]
        [string] $root = "C:\git\ALDINord\Landing-Zone-Management\LZConfig",
        
        [Parameter(Mandatory = $false)]
        [string] $csvFile = "./LZBillingIDs.csv",
        
        [Parameter(Mandatory = $false)]
        [string] $jsonPath = "./mg-corp", #"./mg-online",

        [Parameter(Mandatory = $false)]
        [string] $ConfigVersion = "2.0.0",
        
        [Parameter(Mandatory = $false)]
        [string] $LZVersion = "1.5.0"

    )

Set-Location $root

# Import CSV File with Billing IDs, Tags and more
$csv = Import-Csv $csvFile -Delimiter ";"
# Find all Folders with JSON files in the path
$jsonFolders = Get-ChildItem $jsonPath -Recurse -Filter "*.json"

# create empty arrays
$foundFiles = @()
$notFoundFiles = @()

# Loop through all JSON files
$jsonFolders | foreach-object {

    # Get the JSON-file name
    $folderName = $_ | Select-Object -ExpandProperty DirectoryName  | Split-Path -Leaf
    $jsonFile = $_


    Write-Host "Checking: $folderName"

    # Check if SubscriptionID from JSON file is in the CSV file
    if ($folderName -in $csv.Subscription) {
        Write-Host "Found: $folderName"
        $foundFiles += $folderName

        # Loop through the matched CSV row
        $csv | Where-Object { $_.Subscription -eq $folderName } | foreach-object {
            # Get the JSON File
            $json = $jsonFile | Get-Content | ConvertFrom-Json
            # Copy current csvRow in variable
            $csvRow = $_

            #region Variables
            $context = $csvRow.context
            $deploymentLock = $json.deploymentLock
            $MgmtGrId = $json.MgmtGrId
            $number = $csvRow.number
            $project = $json.project
            $stage = $json.stage
            $vnetAddressPrefix = $json.vnetAddressPrefix
            #$vnetDNSServers = New-Object System.Collections.ArrayList
            $vnetDNSServers = $json.vnetDNSServers

            #ResourceNames
            $rgRsvNorthEurope = $json.ResourceNames.rgRsvNorthEurope
            $rgRsvWestEurope = $json.ResourceNames.rgRsvWestEurope
            $rgVnet = $json.ResourceNames.rgVnet
            $rsvNameNorthEurope = $json.ResourceNames.rsvNameNorthEurope
            $rsvNameWestEurope = $json.ResourceNames.rsvNameWestEurope
            $vnetName = $json.ResourceNames.vnetName

            #Tags
            if ($csvRow.ccoe_billingID -eq $null -or $csvRow.ccoe_billingID -eq "") {
                $ccoe_billingID = $null
            }
            else {
                $ccoe_billingID = $csvRow.ccoe_billingID
            }
            $ccoe_owner = $csvRow.ccoe_owner
            $ccoe_project = $csvRow.ccoe_project
            $ccoe_stage = $csvRow.ccoe_stage

            # if now technicalcontat is set use ccoe_owner as technicalowner
            if ($csvRow.ccoe_technicalcontact -eq $null -or $csvRow.ccoe_technicalcontact -eq "") {
                $ccoe_technicalcontact = $ccoe_owner 
            }
            else {
                $ccoe_technicalcontact = $csvRow.ccoe_technicalcontact
            }

            if ($json.Tag.ccoe_workloadteam -eq $null) {
                $ccoe_workloadteam = "<none>"
            }
            else {
                $ccoe_workloadteam = $json.Tag.ccoe_workloadteam
            }
 
            #endregion

            #region newJson
            $jsonBase = [ordered]@{}
            $jsonBase.Add("ConfigVersion", $ConfigVersion)
            $jsonBase.Add("context", $context)
            $jsonBase.Add("deploymentLock", $deploymentLock)
            $jsonBase.Add("LZVersion", $LZVersion)
            $jsonBase.Add("MgmtGrId", $MgmtGrId)
            $jsonBase.Add("number", $number)
            $jsonBase.Add("project", $project)

            $ResourceNames = New-Object System.Collections.ArrayList
            $ResourceNames = [ordered]@{
                    "rgRsvNorthEurope"                     = $rgRsvNorthEurope; `
                    "rgRsvWestEurope"                      = $rgRsvWestEurope; `
                    "rgVnet"                               = $rgVnet; `
                    "rsvNameNorthEurope"                   = $rsvNameNorthEurope ; `
                    "rsvNameWestEurope"                    = $rsvNameWestEurope; `
                    "vnetName"                             = $vnetName
            }
            $jsonBase.Add("ResourceNames", $ResourceNames)
            $jsonBase.Add("stage", $stage)


            $Tag = New-Object System.Collections.ArrayList
            $Tag = [ordered]@{   
                    "ccoe_billingID" = $ccoe_billingID; `
                    "ccoe_owner"                  = $ccoe_owner; `
                    "ccoe_project"                = $ccoe_project; `
                    "ccoe_stage"                  = $ccoe_stage ; `
                    "ccoe_technicalcontact"       = $ccoe_technicalcontact; `
                    "ccoe_workloadteam"           = $ccoe_workloadteam
            }
            $jsonBase.Add("Tag", $Tag)
            $jsonBase.Add("vnetAddressPrefix", $vnetAddressPrefix)
            $jsonBase.Add("vnetDNSServers", $vnetDNSServers)

            # Write new JSON file
            $jsonBase | ConvertTo-Json -Depth 10 | Out-File $jsonFile
            #endregion
        }
    }
    else {
        Write-Host "Not found: $folderName"
        $notFoundFiles += $folderName
    }
    Write-Host "-----------------------"
}

Write-Host "CSV-File $csvFile "
Write-Host "JSON-Path $jsonPath"
Write-Host "Found files in CSV:"
$foundFiles | ConvertTo-Json
Write-Host "Not found files in CSV:"
$notFoundFiles | ConvertTo-Json