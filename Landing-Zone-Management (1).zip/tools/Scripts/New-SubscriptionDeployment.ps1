
<#
    .SYNOPSIS
    Creates Landing Zone

    .DESCRIPTION
    Creates Subscription for a Landing zone. Includes Validations / Sanity Checks against Azure

    .PARAMETER lzconfigPath
    Mandatory. The lzconfig.json with the fundamental deployment configuration (e.g. Project & Stage)

    .EXAMPLE
    ./tools/Scripts/New-LandingZone.ps1 -lzconfigPath:"lzconfig.json" -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $lzconfigPath,

    [Parameter(Mandatory = $true)]
    [string] $SubscriptionName
)

Write-Verbose ("Subscription name: {0}" -f $SubscriptionName ) -Verbose

#Read Config
$Config = Get-Content -Raw -Path $lzconfigPath | ConvertFrom-Json -Depth 99 -AsHashtable

#Add ccoe_lz_version tag to deployment parameters
If ($Config.ContainsKey('Tag')) {
    $Config.Tag.Add("ccoe_lz_version",$Config.LZVersion)
}

Write-Verbose "Processing Config: " -Verbose
Write-Verbose ($Config | ConvertTo-Json) -Verbose

#region Sanity Checks

# Subscription validation
# -----------------------
# Check if Sub already exists and get ID if
$ExistingSubscriptionId = (Get-AzSubscription -SubscriptionName $SubscriptionName -ErrorAction 'Ignore').id
if (-not $ExistingSubscriptionId) {
    $ExistingSubscriptionId = (Get-AzSubscriptionAlias -AliasName $SubscriptionName -WhatIf:$false -ErrorAction 'Ignore').id
}
if (-not $ExistingSubscriptionId) {
    $ExistingSubscriptionId = (Get-AzSubscriptionAlias -AliasName "alias-$SubscriptionName" -WhatIf:$false -ErrorAction 'Ignore').id
}
if ($ExistingSubscriptionId) {
    Write-Verbose "Found subscription [$SubscriptionName], Subscription Id: [$ExistingSubscriptionId]" -Verbose
    Write-Host "##vso[task.setvariable variable=lzSubscriptionId;]$ExistingSubscriptionId"
}

#endregion Sanity Checks

# Deploy template for LZ
# ----------------------

$TemplateParameterObject = @{
    MgmtGrId                = $Config.MgmtGrId
    subscriptionAlias       = "alias-$SubscriptionName"
    subscriptionDisplayName = $SubscriptionName
}
if ($ExistingSubscriptionId) {
    $TemplateParameterObject['ExistingSubscriptionID'] = $ExistingSubscriptionId
}

$DeploymentParams = @{
    DeploymentName          = "Sub-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
    ManagementGroupId       = $Config.MgmtGrId
    TemplateFile            = "$PSScriptRoot/../.bicep/deploySubscription.bicep"
    location                = "westeurope"
    TemplateParameterObject = $TemplateParameterObject 
    Verbose                 = $true
}

Write-Verbose "Invoke deployment with" -Verbose
Write-Verbose ($DeploymentParams | ConvertTo-Json | Out-String) -Verbose

Test-AzManagementGroupDeployment @DeploymentParams 

if ($PSCmdlet.ShouldProcess("Management-group-level deployment for subscription [$SubscriptionName]", "Invoke")) {
    $res = New-AzManagementGroupDeployment @DeploymentParams
    Write-Verbose ($res.Outputs | ConvertTo-Json -Depth 10 | Out-String) -Verbose
    Write-Host "##vso[task.setvariable variable=lzSubscriptionId;]$($res.Outputs.subscriptionId.Value)"
}
else {
    New-AzManagementGroupDeployment @DeploymentParams -WhatIf
}
