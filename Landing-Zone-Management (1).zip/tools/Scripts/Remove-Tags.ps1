<#
.SYNOPSIS
Remove all occurences of an Azure tag from the subscription, its resource group and resources

.DESCRIPTION
Remove all occurences of an Azure tag from the subscription, its resource group and resources

.PARAMETER TagName
Required. Name of the tag to remove

.PARAMETER SubscriptionId
Required. Id of the subscription to remove tag from

.EXAMPLE
Remove-Tags -TagName "Tag1" -SubscriptionId "11111111-1111-1111-1111-111111111111"
#>

function Remove-Tags {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$TagNames,

        [Parameter(Mandatory = $true)]
        [string]$SubscriptionId
    )

    Write-Verbose ('SubscriptionId=[{0}]...' -f $SubscriptionId)
    Write-Verbose ('Tags to be removed (function input):')
    Write-Verbose ('{0}' -f $(($TagNames | ConvertTo-Json | Out-String).TrimEnd()))

    # verifying if subscription exists
    $subscription = Get-AzSubscription -SubscriptionId $SubscriptionId -ErrorAction SilentlyContinue
    Write-Host ('Subscription found. Subscription name: [{0}]...' -f $subscription.Name)

    # removing tag from the subscription
    if ($subscription) {
        Write-Host "##[section]STEP 1: Removing tags on subscription level..."
        Remove-TagsFromSubscription -TagNames $TagNames -SubscriptionId $SubscriptionId
        Write-Host ('##[section]STEP 1 finished')
    }
    else {
        throw ('Subscription with the id [{0}] not found' -f $SubscriptionId)
    }

    # removing tag from resource groups
    Write-Host "##[section]STEP 2: Removing tags from Resource Groups..."
    Remove-TagsFromResourceGroups -TagNames $TagNames -SubscriptionId $SubscriptionId
    Write-Host ('##[section]STEP 2 finished')

    # removing tag from all resources
    Write-Host "##[section]STEP 3: Removing tags from Resources..."
    Remove-TagsFromResources -TagNames $TagNames -SubscriptionId $SubscriptionId
    Write-Host ('##[section]STEP 3 finished')

    # verifying if tags are removed
    Write-Host "##[section]STEP 4: Finally confirming tags removal..."
    $allTags = Get-AzTag
    Write-Host ('##[group]Overall tags usage in the subscription after removal')
    Write-Host ('All tags remaining in the subscription:')
    Write-Host ('{0}' -f $(($allTags | ConvertTo-Json | Out-String).TrimEnd()))
    Write-Host ('##[endgroup]')
    $tagsWhichShouldNotBeThere = $allTags | Where-Object -FilterScript { $_.Name -in $TagNames }
    if ($tagsWhichShouldNotBeThere) {
        $allTags = Get-AzTag
        Write-Host ('##[error]Tags, which should be removed, but are still there:')
        Write-Host ('{0}' -f $(($notRemovedTags | ConvertTo-Json | Out-String).TrimEnd()))
        throw "Some tags were not removed properly"
    }
    else {
        Write-Host ('##[section]Success! All tags to be removed have been removed successfully.')
    }
}

<#
.SYNOPSIS
Remove tag on the subscription level

.DESCRIPTION
Remove tag on the subscription level

.PARAMETER TagNames
Required. Array of strings representing names of the tags to remove

.PARAMETER SubscriptionId
Required. Id of the subscription to remove tags from

.EXAMPLE
Remove-TagsFromSubscription -TagNames "Tag1", "Tag2", "Tag3" -SubscriptionId "11111111-1111-1111-1111-111111111111"
#>

function Remove-TagsFromSubscription {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$TagNames,

        [Parameter(Mandatory = $true)]
        [string]$SubscriptionId,

        [Parameter(Mandatory = $false)]
        [byte]$VerifyAttempts = 5,

        [Parameter(Mandatory = $false)]
        [uint]$SecondsBetweenVerifyAttempts = 15

    )

    begin {
        Write-Host "##[group] Processing subscription"
    }

    process {
        $subTags = Get-AzTag -ResourceId "/subscriptions/$SubscriptionId"
    
        Write-Verbose ('Tags to be removed (function input):')
        Write-Verbose ('{0}' -f $(($TagNames | ConvertTo-Json | Out-String).TrimEnd()))
    
        if ($subTags.Properties.TagsProperty.Count -gt 0) {
            Write-Host ('Number of tags found on the subscription level before removal: [{0}]:' -f $subTags.Properties.TagsProperty.Count)
            Write-Host ('Subscription tags before removal: {0}' -f $(($subTags.Properties.TagsProperty.Keys | ConvertTo-Json | Out-String).TrimEnd()))
    
            # searching for matching tags
            $tagsToRemove = @{}
            foreach ($key in $subTags.Properties.TagsProperty.Keys) {
                if ($TagNames.Contains($key)) {
                    $tagsToRemove.Add($key, $subTags.Properties.TagsProperty[$key])            
                }
            }
    
            if ($tagsToRemove.Count -gt 0) {
                Write-Host ('Number of matching tags found [{0}]. Removing...' -f $tagsToRemove.Count)
                $null = Update-AzTag -ResourceId "/subscriptions/$SubscriptionId" -Tag $tagsToRemove -Operation Delete
            }
            else {
                Write-Host ('No tags to remove identified. Removal not needed...')
                Return
            }
        }
        else {
            Write-Host ('No tags found on the subscription level. Removal not needed...')
            Return
        }
    
        # verifying if tag has been removed
        for ($i = 0; $i -lt $VerifyAttempts; $i++) {
            $subTags = Get-AzTag -ResourceId "/subscriptions/$SubscriptionId"
            Write-Host ('Verifying if tags were removed sucessfully, attempt [{0}]...' -f $($i + 1))
    
            $tagsToRemove = @{}
            foreach ($key in $subTags.Properties.TagsProperty.Keys) {
                if ($TagNames.Contains($key)) {
                    $tagsToRemove.Add($key, $subTags.Properties.TagsProperty[$key])            
                }
            }
    
            if ($tagsToRemove.Count -eq 0) {
                Write-Host ('Number of remaining tags on the subscription level after removal: [{0}]:' -f $subTags.Properties.TagsProperty.Count)
                if ($subTags.Properties.TagsProperty.Count -gt 0) {
                    Write-Host ('Subscription tags after removal: {0}' -f $(($subTags.Properties.TagsProperty.Keys | ConvertTo-Json | Out-String).TrimEnd()))
                }
                Write-Host ('Tags were removed successfully.')
                Return
            }
            Start-Sleep -Seconds $SecondsBetweenVerifyAttempts
        }
    
        Write-Host ('##[error]Some of the tags could not be removed.')
        if ($subTags.Properties.TagsProperty.Count -gt 0) {
            Write-Host ('##[error]Remaining subscription tags: {0}' -f $(($subTags.Properties.TagsProperty.Keys | ConvertTo-Json | Out-String).TrimEnd()))
        }
    }

    end {
        Write-Host "##[endgroup]"
    }

}

<#
.SYNOPSIS
Remove tags from resource groups

.DESCRIPTION
Remove tags from resource groups

.PARAMETER TagNames
Required. Array of strings representing names of the tags to remove

.PARAMETER SubscriptionId
Required. Id of the subscription to remove tags from

.EXAMPLE
Remove-TagsFromResourceGroups -TagNames "Tag1", "Tag2", "Tag3" -SubscriptionId "11111111-1111-1111-1111-111111111111"
#>

function Remove-TagsFromResourceGroups {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$TagNames,

        [Parameter(Mandatory = $true)]
        [string]$SubscriptionId,

        [Parameter(Mandatory = $false)]
        [byte]$VerifyAttempts = 5,

        [Parameter(Mandatory = $false)]
        [uint]$SecondsBetweenVerifyAttempts = 15

    )

    # searching for resource groups, which contain at least one tag from the $TagNames list
    $matchingResourceGroups = Get-AzResourceGroup | Where-Object -FilterScript { 
        $_.Tags.Count -gt 0 `
            -and `
        (Compare-Object -ReferenceObject $($_.Tags.Keys) -DifferenceObject $TagNames -IncludeEqual -ExcludeDifferent).Count -gt 0 
    }

    # if matching resource groups found, processing them
    if ($matchingResourceGroups.Count -gt 0) {
        Write-Host('Number of resource groups containing at least one tag to remove: [{0}]:' -f $matchingResourceGroups.Count)

        $counter = 0
        foreach ($rg in $matchingResourceGroups) {
            $counter++
            Write-Host('##[group]Processing Resource Group [{1} of {2}]: [{0}]...' -f $rg.ResourceGroupName, $counter, $matchingResourceGroups.Count)
            if ($rg.Tags.Count -gt 0) {
                Write-Host('Number of tags found on the resource group before removal: [{0}]:' -f $rg.Tags.Count)
                Write-Host('Resource group tags before removal: {0}' -f $(($rg.Tags.Keys | ConvertTo-Json | Out-String).TrimEnd()))

                # searching for matching tags and creating a list of tags to remove
                $tagsToRemove = @{}
                foreach ($key in $rg.Tags.Keys) {
                    if ($TagNames.Contains($key)) {
                        $tagsToRemove.Add($key, $rg.Tags[$key])            
                    }
                }

                # performing removal
                if ($tagsToRemove.Count -gt 0) {
                    Write-Host('Number of matching tags found [{0}]. Removing...' -f $tagsToRemove.Count)
                    $null = Update-AzTag -ResourceId $rg.ResourceId -Tag $tagsToRemove -Operation Delete -ErrorAction SilentlyContinue

                    $rgTags = Get-AzTag -ResourceId $rg.ResourceId
                    Write-Host('Number of tags found on the resource group after removal: [{0}]:' -f $rgTags.Properties.TagsProperty.Count)
                    if ($rgTags.Properties.TagsProperty.Count -gt 0) {
                        Write-Host('Resource group tags after removal: {0}' -f $(($rgTags.Properties.TagsProperty.Keys | ConvertTo-Json | Out-String).TrimEnd()))
                    }
                    Write-Host "##[endgroup]"
                }
                else {
                    Write-Host('No tags to remove identified. Removal not needed...')
                    Write-Host "##[endgroup]"
                    continue
                }
            }
            else {
                Write-Host('No tags found on the resource group. Removal not needed...')
                Write-Host "##[endgroup]"
                continue
            }
        }
    }
    else {
        Write-Host('No resource groups with matching tags found. Removal not needed...')
        Return
    }

    # verifying if tag has been removed
    for ($i = 0; $i -lt $VerifyAttempts; $i++) {
        Write-Host('Verifying if tags were removed sucessfully, attempt [{0}]...' -f $($i + 1))

        # again searching for resource groups, which contain at least one tag from the $TagNames list
        $matchingResourceGroups = Get-AzResourceGroup | Where-Object -FilterScript {
            $_.Tags.Count -gt 0 `
                -and `
            (Compare-Object -ReferenceObject $($_.Tags.Keys) -DifferenceObject $TagNames -IncludeEqual -ExcludeDifferent).Count -gt 0 
        }

        # if the result is empty, function done the job successfully
        if ($matchingResourceGroups.Count -eq 0) {
            Write-Host('Tags were removed successfully.' -f $TagName)
            Return
        }
        Start-Sleep -Seconds $SecondsBetweenVerifyAttempts
    }

    Write-Error ('Some of the tags could not be removed.')
}

<#
.SYNOPSIS
Remove tags from resources

.DESCRIPTION
Remove tags from resources

.PARAMETER TagNames
Required. Array of strings representing names of the tags to remove

.PARAMETER SubscriptionId
Required. Id of the subscription to remove tags from

.EXAMPLE
Remove-TagsFromResources -TagNames "Tag1", "Tag2", "Tag3" -SubscriptionId "11111111-1111-1111-1111-111111111111"
#>
function Remove-TagsFromResources {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$TagNames,

        [Parameter(Mandatory = $true)]
        [string]$SubscriptionId,

        [Parameter(Mandatory = $false)]
        [byte]$VerifyAttempts = 5,

        [Parameter(Mandatory = $false)]
        [uint]$SecondsBetweenVerifyAttempts = 15

    )

    # searching for resources, which contain at least one tag from the $TagNames list
    $matchingResources = Get-AzResource | Where-Object -FilterScript { 
        $_.Tags.Count -gt 0 `
            -and `
        (Compare-Object -ReferenceObject $($_.Tags.Keys) -DifferenceObject $TagNames -IncludeEqual -ExcludeDifferent).Count -gt 0 
    }

    # if matching resources found, processing them
    if ($matchingResources.Count -gt 0) {
        Write-Host ('Number of resources containing at least one tag to remove: [{0}]:' -f $matchingResources.Count)

        $counter = 0
        foreach ($res in $matchingResources) {
            $counter++
            Write-Host ('##[group]Processing Resource [{1} of {2}]: [{0}]...' -f $res.Id, $counter, $matchingResources.Count)
            if ($res.Tags.Count -gt 0) {
                Write-Host ('Number of tags found on the resource before removal: [{0}]:' -f $res.Tags.Count)
                Write-Host ('Resource tags before removal: {0}' -f $(($res.Tags.Keys | ConvertTo-Json | Out-String).TrimEnd()))

                # searching for matching tags and creating a list of tags to remove
                $tagsToRemove = @{}
                foreach ($key in $res.Tags.Keys) {
                    if ($TagNames.Contains($key)) {
                        $tagsToRemove.Add($key, $res.Tags[$key])            
                    }
                }

                # performing removal
                if ($tagsToRemove.Count -gt 0) {
                    Write-Host ('Number of matching tags found [{0}]. Removing...' -f $tagsToRemove.Count)
                    $null = Update-AzTag -ResourceId $res.ResourceId -Tag $tagsToRemove -Operation Delete -ErrorAction SilentlyContinue

                    $resTags = Get-AzTag -ResourceId $res.ResourceId
                    Write-Host('Number of tags found on the resource after removal: [{0}]:' -f $resTags.Properties.TagsProperty.Count)
                    if ($resTags.Properties.TagsProperty.Count -gt 0) {
                        Write-Host('Resource tags after removal: {0}' -f $(($resTags.Properties.TagsProperty.Keys | ConvertTo-Json | Out-String).TrimEnd()))
                    }
                    Write-Host "##[endgroup]"
                }
                else {
                    Write-Host ('No tags to remove identified. Removal not needed...')
                    Write-Host "##[endgroup]"
                    continue
                }
            }
            else {
                Write-Host ('No tags found on the resource. Removal not needed...')
                Write-Host "##[endgroup]"
                continue
            }
        }
    }
    else {
        Write-Host ('No resources with matching tags found. Removal not needed...')
        Return
    }

    # verifying if tag has been removed
    for ($i = 0; $i -lt $VerifyAttempts; $i++) {
        Write-Host ('Verifying if tags were removed sucessfully, attempt [{0}]...' -f $($i + 1))

        # again searching for resource groups, which contain at least one tag from the $TagNames list
        $matchingResources = Get-AzResource | Where-Object -FilterScript {
            $_.Tags.Count -gt 0 `
                -and `
            (Compare-Object -ReferenceObject $($_.Tags.Keys) -DifferenceObject $TagNames -IncludeEqual -ExcludeDifferent).Count -gt 0 
        }

        # if the result is empty, function done the job successfully
        if ($matchingResources.Count -eq 0) {
            Write-Host ('Tags were removed successfully.' -f $TagName)
            Return
        }
        Start-Sleep -Seconds $SecondsBetweenVerifyAttempts
    }

    Write-Error ('Some of the tags could not be removed.')
    Return
}
