<#
.SYNOPSIS
Send mail message

.DESCRIPTION
The function is sending mail message to given email addess

.PARAMETER To
Required. Recipient mail or addresses (semicolon separated)

.PARAMETER Cc
Required. Cc mail or addresses (semicolon separated)

.PARAMETER Body
Required. Message body

.EXAMPLE
Send-Notification -To "email@domain" -Cc "email2@domain2" -body $body
#>

function Send-Notification {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$To,

        [Parameter(Mandatory = $true)]
        [string]$Cc,

        [Parameter(Mandatory = $true)]
        [string]$Body,

        [Parameter(Mandatory = $true)]
        [string]$Subject
    )

    $message = New-Object Net.Mail.MailMessage
    $message.From = "noreply@aldi-nord.de"
    foreach ($mailTo in $to.Split(";")) {
        $message.To.Add($mailTo)
    }
    foreach ($mailCc in $cc.Split(";")) {
        $message.Cc.Add($mailCc)
    }
    $message.Subject = $Subject
    $message.IsBodyHtml = $true
    $message.Body = $Body

    $smtp = New-Object Net.Mail.SmtpClient("cmail.servicemail24.de", "587")
    $smtp.EnableSSL = $true
    $login = "m1044_aldi-nord6"
    $pw = Get-AzKeyVaultSecret -VaultName 'kv-ccoe-prod-mgmt-001' -Name 'm1044-aldi-nord6' -AsPlainText -Verbose
    $smtp.Credentials = New-Object System.Net.NetworkCredential($login, $pw)
    
    Write-Verbose ("Sending to mail:{0} cc:{1}" -f $To,$Cc) -Verbose

    try {
        $smtp.send($message)
    }
    catch {
        Write-Verbose ("Exception caught in sending message to mail:{0} cc:{1}" -f $To,$Cc) -Verbose
        Write-Verbose ($PSitem.Exception.Message | Out-String) -Verbose    
    }

}