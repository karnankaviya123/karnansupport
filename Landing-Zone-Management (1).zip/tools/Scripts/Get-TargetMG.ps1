<#
.SYNOPSIS
Gets target Management Group

.DESCRIPTION
Gets target Management Group basing on input parameters

.PARAMETER MGID
Mandatory. Management Group ID

.PARAMETER Stage
Mandatory. Landing Zone Stage

.EXAMPLE
Get-TargetMG -MGID "mg-corp" -Stage "dev"

Returns "mg-dev-corp"
#>

function Get-TargetMG {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $MGID,

        [Parameter(Mandatory = $true)]
        [string] $Stage
    )

    If ($Stage -eq "dev") {
        $outputMGID = "dev-"+$MGID
    }
    else {
        $outputMGID = $MGID
    }
    
    return $outputMGID
}