[CmdletBinding()]
param (
    [parameter(mandatory = $true)]
    [string] $subscriptionName,
    [parameter(mandatory = $true)]
    [string] $validateOnly
)
$virtualHubName = "hub-we-prod-01"
$virtualHubSubscription = "sub-de-ohg-ats-dcs-cnct-prd"

function Remove-VirtualNetworkPeerings {
    <#
    .SYNOPSIS
    Remove virtual network peerings

    .DESCRIPTION
    Remove virtual network peering and virtual network connection from Virtual Hub

    .PARAMETER subscriptionName
    Required. Name of Subscription.

    .PARAMETER virtualHubName
    Required. Name of Virtual Hub.

    .PARAMETER virtualHubSubscription
    Required. Name of subscription where Virtual Hub is deployed.

     .PARAMETER validateOnly
    Required. Validate mode enabled or disabled

    .EXAMPLE
    Remove-VirtualNetworkPeerings -subscriptionName "sub-xxx-xxx" -virtualHubName "vhub-001" -virtualHubSubscription "sub-yyy-xxx" -validateOnly $true

    #>
    [CmdletBinding()]
    param (
        [parameter(mandatory = $true)]
        [string] $subscriptionName,
        [parameter(mandatory = $true)]
        [string] $virtualHubName,
        [parameter(mandatory = $true)]
        [string] $virtualHubSubscription,
        [parameter(mandatory = $true)]
        [string] $validateOnly
    )
    
    $subscriptionGraphQuery = "resourcecontainers
        | where type == 'microsoft.resources/subscriptions'
        | where name == '{0}'" -f $subscriptionName
    $subscriptionProperties = Search-AzGraph -Query $subscriptionGraphQuery
    $virtualNetworksGraphQuery = "resources 
        | where type == 'microsoft.network/virtualnetworks' 
        | where subscriptionId == '{0}'" -f $subscriptionProperties.subscriptionId
    $virtualHubGraphQuery = "resources 
        | where type == 'microsoft.network/virtualhubs'
        | where name == '{0}'" -f $virtualHubName

    $virtualNetworks = Search-AzGraph -Query $virtualNetworksGraphQuery
    $virtualHubProperties = Search-AzGraph -Query $virtualHubGraphQuery

    Set-AzContext -Subscription $virtualHubSubscription
    $virtualHubConnection = Get-AzVirtualHubVnetConnection -ResourceGroupName $virtualHubProperties.resourceGroup -VirtualHubName $virtualHubProperties.name | 
        Select-Object @{N='VirtualHubConnectionId'; E={$_.Id}}, Name -ExpandProperty RemoteVirtualNetwork | 
        Where-Object -Property Id -eq $virtualNetworks.id -Verbose

    Write-Verbose ("Validate only: {0}" -f $validateOnly) -Verbose
    if (($validateOnly -ne $true) -and ($virtualHubConnection.name -ne $null)) {
        Write-Verbose ("Removing {0}" -f $virtualHubConnection.name) -Verbose
        Remove-AzVirtualHubVnetConnection -ResourceGroupName $virtualHubProperties.resourceGroup -ParentResourceName $virtualHubProperties.name -Name $virtualHubConnection.name -Force
    }
    elseif ($virtualHubConnection.name -ne $null) {
        Write-Verbose ("(WhatIf) Removing {0}" -f $virtualHubConnection.name) -Verbose
        Remove-AzVirtualHubVnetConnection -ResourceGroupName $virtualHubProperties.resourceGroup -ParentResourceName $virtualHubProperties.name -Name $virtualHubConnection.name -WhatIf
    }
    else {
        Write-Verbose ("Cannot find Virtual Hub connection for subscription {0}" -f $subscriptionName) -Verbose
    }
}

Remove-VirtualNetworkPeerings -subscriptionName $subscriptionName -virtualHubName $virtualHubName -virtualHubSubscription $virtualHubSubscription -validateOnly $validateOnly