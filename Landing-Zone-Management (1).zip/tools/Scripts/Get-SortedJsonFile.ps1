#region Helper functions
<#
.SYNOPSIS
Sorts properies of a Json file alphabetically

.DESCRIPTION
Sorts properies of a Json file and overwrites it with the sorted content.

.PARAMETER jsonFilePath
Mandatory. The input Json file path

.EXAMPLE
Get-SortedJsonFile jsonFileToSort $jsonPath

Overwrites a json file with the same properties, but sorted alphabetically
#>
function Get-SortedJsonFile {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $jsonFilePath
    )

    Write-Verbose ('Starting Json sorting for [{0}]' -f $jsonFilePath)

    # Verifying the the file exists
    if (!(Test-Path $jsonFilePath)) {
        throw 'File [{0}] not found.' -f $jsonFilePath
    }
    else {
        Write-Verbose ('File [{0}] found' -f $jsonFilePath) -Verbose
    }

    # Reading content of the file and creating a hashtable
    $myHashTable = Get-Content -Raw -Path $jsonFilePath | ConvertFrom-Json -Depth 99 -AsHashtable

    # Using the Get-SortedHashTable function to recursively sort the properties of the hash table
    $sortedHashTable = Get-SortedHashTable -inputHashTable $myHashTable -recursive $true

    # converting hashtable to an PSCustomObject as a preparation to generate a new, sorted JSON file
    $sortedObj = [pscustomobject]$sortedHashTable
    # converting to JSON and overwriting the input file 
    $sortedObj | ConvertTo-Json -depth 100 | Set-Content $jsonFilePath -Force
}

<#
.SYNOPSIS
Creates a deep copy of a hashtable

.DESCRIPTION
Creates a deep copy (including nested hashtables) of a hashtable, keeping it a hashtable
Function found at: https://docs.microsoft.com/en-us/powershell/scripting/learn/deep-dives/everything-about-hashtable?view=powershell-7.2#deep-copies

.PARAMETER InputObject
Mandatory. The input hashtable

.EXAMPLE
Get-DeepClone -InputObject $myHashTable

Returns a deep copy of the input hashtable
#>
function Get-DeepClone {
    [CmdletBinding()]
    param(
        $InputObject
    )
    process {
        if ($InputObject -is [hashtable]) {
            $clone = @{}
            foreach ($key in $InputObject.keys) {
                $clone[$key] = Get-DeepClone $InputObject[$key]
            }
            return $clone
        }
        else {
            return $InputObject
        }
    }
}

<#
.SYNOPSIS
Sorts hashtable by key names

.DESCRIPTION
Sorts hashtable by key names alphabetically and optopnally recursive

.PARAMETER inputHashTable
Mandatory. The input hashtable

.PARAMETER recursive
Optional. If hashtable has hashtables as values, they will be sorted too

.EXAMPLE
Get-SortedHashTable -inputHashTable $myHashTable -recursive $true

Returns a hashtable with the same key/values, but sorted alphabetically by the keys
#>
function Get-SortedHashTable {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable] $inputHashTable,

        [Parameter(Mandatory = $false)]
        [bool] $recursive = $false
    )

    Write-Verbose ('Sorting hashtable with [{0}] items start' -f $inputHashTable.Count)

    # creating a clone of the input hashtable. This is necessary, 
    # because you can't modify a hashtable while it's being enumerated, causing error:
    # "An error occurred while enumerating through a collection: Collection was modified; enumeration operation may not execute.."
    # Therefore we will enumerate though the copy, but modify the original hashtable
    $inputClone = Get-DeepClone -InputObject $inputHashTable

    # if the parameter "-recursive" has been selected, we go through the properties of the hashtable
    # and if the value is also a hashtable, we are sorting its properties by launching this function recursively.
    # As mentioned above, the ForEach-Object goes through the copy, but the sorted result is stored in the input object
    try {
        if ($recursive) {
            $inputClone.Keys | ForEach-Object {
                if ($inputClone[$_] -is [Hashtable]) {
                    $inputHashTable[$_] = Get-SortedHashTable -inputHashTable $inputClone[$_] -recursive $true
                }  
            }
        }
    }
    catch {
        Write-Verbose "Recursive processing failed..." -Verbose
        Write-Verbose ($PSitem.Exception.Message | Out-String) -Verbose    
    }

    # creating an ordered result object, sorting the hashtable by the key
    # and copying each key/value pair to the result object
    try {
        $res = [ordered] @{}
        $inputHashTable.GetEnumerator() | Sort-Object -Property Key |
        ForEach-Object { $res[$_.Name] = $inputHashTable.$($_.Name) }    
    }
    catch {
        Write-Verbose "Building the result object failed..." -Verbose
        Write-Verbose ($PSitem.Exception.Message | Out-String) -Verbose    
    }

    Write-Verbose ('Sorting hashtable with [{0}] items end' -f $inputHashTable.Count)

    # returning the result object
    return $res
}
