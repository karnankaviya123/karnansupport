
function Get-CCoENotificationGroupMembers {
    <#
    .SYNOPSIS
    Gets CCoE notification group members

    .DESCRIPTION
    Gets CCoE notification group members (admin account managers) for each member in security group 

    .PARAMETER SecurityGroupName
    Mandatory. Name of source seciruty group

    .PARAMETER NotificationGroupName
    Mandatory. Name of target Notification group where members will be added

    .EXAMPLE
    Get-CCoENotificationGroupMembers -SecurityGroupName "WW.MST.lztstcorp.sub.DEV.Contributor" -NotificationGroupName "AZR.AA.ALL.O365.sub-lztstcorp-dev.Notification"

    Returns list of notification group members

    Run "Connect-AzureAD" before function execution.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string] $securityGroupName,
        [Parameter(Mandatory = $true)]
        [string] $notificationGroupName
    )

    $allGroups = Get-AzureADGroup -All $true
    $securityGroups = $allGroups | Where-Object {$_.DisplayName -eq $securityGroupName}
    $notificationGroup = $allGroups | Where-Object {$_.DisplayName -eq $NotificationGroupName}

    foreach ($group in $securityGroups) {

        $groupMembers = Get-AzureADGroup -ObjectId $group.ObjectId | Get-AzureADGroupMember

        # Get Contributor group members and managers. Manager accounts of "admin" users are regular email accounts which will be used for Notifications
        foreach ($member in $groupMembers) {
            $user = Get-AzureADUser -ObjectId $member.ObjectId
            $userManager = Get-AzureADUserManager -ObjectId $member.ObjectId
            
            if ($userManager.UserPrincipalName.ToLower() -ne $null) {
                # If user surname from "DisplayName" is included in Manager UPN, notification email for that user is Manager UPN
                if ($userManager.UserPrincipalName.ToLower().Contains($user.DisplayName.ToLower().Split(" ")[1])) {
                    $notificationMail = $userManager.UserPrincipalName
                }
                # If user surname from "DisplayName" is included in user UPN, notification email for that user is his email
                elseif ($user.UserPrincipalName.ToLower().Contains($user.DisplayName.ToLower().Split(" ")[1])) {
                    $notificationMail = $user.UserPrincipalName
                }
                else {
                    $notificationMail = $false
                }
            }

            if ($notificationMail) {
                $output = New-Object PSObject -Property @{
                    UserNameUPN = $user.UserPrincipalName
                    GroupName = $group.DisplayName
                    UserManagerUPN = $userManager.UserPrincipalName
                    NotificationGroupName = $notificationGroup.DisplayName
                    NotificationMail = $notificationMail
                }
                Write-Output $output
            }
        }
    }
}

function Add-CCoENotificationGroupMembers {
        <#
    .SYNOPSIS
    Adds CCoE notification group members

    .DESCRIPTION
    Adds CCoE notification group members. Notification group members are account managers of Admin accounts (account must have an email address to recieve notification). 

    .PARAMETER SecurityGroupName
    Mandatory. Name of source seciruty group

    .PARAMETER NotificationGroupName
    Mandatory. Name of target Notification group where members will be added

    .EXAMPLE
    Add-CCoENotificationGroupMembers -SecurityGroupName "WW.MST.lztstcorp.sub.DEV.Contributor" -NotificationGroupName "AZR.AA.ALL.O365.sub-lztstcorp-dev.Notification".

    "Groups Administrator" Azure AD role is required to run this function.

    Run "Connect-AzureAD" before function execution.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string] $securityGroupName,
        [Parameter(Mandatory = $true)]
        [string] $notificationGroupName
    )

    $allGroups = Get-AzureADGroup -All $true
    $securityGroups = $allGroups | Where-Object {$_.DisplayName -eq $securityGroupName}
    $notificationGroup = $allGroups | Where-Object {$_.DisplayName -eq $NotificationGroupName}

    foreach ($group in $securityGroups) {

        $groupMembers = Get-AzureADGroup -ObjectId $group.ObjectId | Get-AzureADGroupMember
        
        # Get Contributor group members and managers. Manager accounts of "admin" users are regular email accounts which will be used for Notifications
        foreach ($member in $groupMembers) {
            $user = Get-AzureADUser -ObjectId $member.ObjectId
            $userManager = Get-AzureADUserManager -ObjectId $member.ObjectId

            if ($userManager.UserPrincipalName.ToLower() -ne $null) {
                # If user surname from "DisplayName" is included in Manager UPN, notification email for that user is Manager UPN
                if ($userManager.UserPrincipalName.ToLower().Contains($user.DisplayName.ToLower().Split(" ")[1])) {
                    $notificationMail = $userManager.UserPrincipalName
                    $userObjectId = $userManager.ObjectId
                }
                # If user surname from "DisplayName" is included in user UPN, notification email for that user is his email
                elseif ($user.UserPrincipalName.ToLower().Contains($user.DisplayName.ToLower().Split(" ")[1])) {
                    $notificationMail = $user.UserPrincipalName
                    $userObjectId = $user.ObjectId
                }
                else {
                    $notificationMail = $false
                }
            }

            if ($notificationMail) {
                if (!(Get-AzureADUserMembership -ObjectId $userObjectId).ObjectId.Contains("$notificationGroup.ObjectId")) {
                    Write-Verbose ("Adding [{0}] to [{1}]" -f $notificationMail,$notificationGroup.DisplayName) -Verbose
                    Add-AzureADGroupMember -ObjectId $notificationGroup.ObjectId -RefObjectId $userObjectId
                }
            }
        }
    }
}


