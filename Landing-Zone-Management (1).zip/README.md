# Landing Zone Management
## Introduction
The purpose of this repository is to provide an automation to deploy the Landing zone and all required components. Landing Zone Maintenance pipelines supports the full lifecycle of Landing Zone enabling creation, updates and removal of each managed Landing Zone.  
Learn more [Landing Zone documentation](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/3165/Landing-Zones)

## Pipelines usage guidelines

### [Create Landing Zone](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/2766/Landing-Zones-Creation?anchor=landing-zone-creation-pipeline-usage)

### [Update Landing Zones](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/997/Landing-Zones-Maintenance?anchor=landing-zone-update-pipeline-usage)

### [Remove Landing Zone](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/3135/Landing-Zones-Decommission?anchor=remove-landing-zone-pipeline-usage)

## Landing Zones release notes

### [Landing Zone versions](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/2521/LZ-Releases-and-Notes)

### [Config file versions](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/2523/Config-File-Releases-and-Notes)

## Useful links

### [Resource Naming Convention](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/170/Naming-Convention)

### [Tagging Convention](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/171/Tagging-Convention)

# For repository contributors
## [Coding Standards](https://dev.azure.com/an-de-ohg-sbi/Azure%20Cloud%20Foundation/_wiki/wikis/CCoE%20Private%20Wiki/3100/Platform-Team)